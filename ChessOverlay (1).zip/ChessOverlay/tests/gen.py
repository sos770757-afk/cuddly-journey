import sys, os, random
from PIL import Image, ImageDraw, ImageFont
import numpy as np

DEJAVU = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
GLYPH = {'K':0x265A,'Q':0x265B,'R':0x265C,'B':0x265D,'N':0x265E,'P':0x265F}
START = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR"
GAME = "e2e4 a7a6 e4e5 d7d5 e5d6 c7d6 g1f3 b8c6 f1c4 g8f6 e1g1 c8g4 d2d3 e7e6 c4e6 f7e6".split()

def sq(s): return (int(s[1])-1)*8 + (ord(s[0])-97)
def from_fen(f):
    b = ['.']*64
    for i,row in enumerate(f.split('/')):
        r = 7-i; c = 0
        for ch in row:
            if ch.isdigit(): c += int(ch)
            else: b[r*8+c] = ch; c += 1
    return b
def apply(b, u):
    f, t = sq(u[:2]), sq(u[2:4]); pc = b[f]
    if pc.upper()=='P' and f%8 != t%8 and b[t]=='.': b[t + (-8 if pc.isupper() else 8)] = '.'
    b[t] = pc; b[f] = '.'
    if len(u)==5: b[t] = u[4].upper() if pc.isupper() else u[4].lower()
    if pc.upper()=='K' and abs(t-f)==2:
        if t>f: b[t-1], b[t+1] = b[t+1], '.'
        else: b[t+1], b[t-2] = b[t-2], '.'

def render(b, geo, theme, font_path, flipped, last, noise, texture, dots, out, W=1080, H=2400, check=None, scale=0.82):
    x0,y0,size = geo; cell = size/8.0
    img = Image.new("RGB",(W,H),(32,34,40)); d = ImageDraw.Draw(img)
    f40 = ImageFont.truetype(DEJAVU, 38)
    d.rectangle([0,0,W,180],fill=(48,50,58)); d.ellipse([30,50,110,130],fill=(110,120,200))
    d.text((130,70),"Bot Level 4  (1200)",fill=(235,235,235),font=f40)
    d.rectangle([0,y0+size+40,W,y0+size+200],fill=(48,50,58)); d.text((130,y0+size+90),"You",fill=(235,235,235),font=f40)
    for k in range(5): d.rectangle([60+k*190,H-260,60+k*190+150,H-130],fill=(70,74,86))
    rnd = random.Random(5)
    def cellrect(i,j): return (round(x0+j*cell), round(y0+i*cell), round(x0+(j+1)*cell), round(y0+(i+1)*cell))
    for i in range(8):
        for j in range(8):
            light = (i+j)%2==0
            col = np.array(theme[0] if light else theme[1], dtype=float)
            if texture: col += rnd.uniform(-9,9)
            r = cellrect(i,j)
            d.rectangle([r[0],r[1],r[2]-1,r[3]-1], fill=tuple(int(v) for v in col))
    # подсветка последнего хода
    def ij(s):
        rank, file = s//8, s%8
        return (rank, 7-file) if flipped else (7-rank, file)
    if last:
        ov = Image.new("RGBA",(W,H),(0,0,0,0)); od = ImageDraw.Draw(ov)
        for s in last:
            i,j = ij(s); r = cellrect(i,j); od.rectangle([r[0],r[1],r[2]-1,r[3]-1], fill=(255,235,60,110))
        img = Image.alpha_composite(img.convert("RGBA"), ov).convert("RGB"); d = ImageDraw.Draw(img)
    if check is not None:
        i,j = ij(check); r = cellrect(i,j); cw = r[2]-r[0]
        ys, xs = np.mgrid[0:cw, 0:cw]; rad = np.hypot(xs-cw/2, ys-cw/2)/(cw*0.62)
        alpha = np.clip((1.0-rad)/0.75, 0, 1)[...,None]*0.95
        patch = np.asarray(img.crop((r[0],r[1],r[0]+cw,r[1]+cw))).astype(float)
        red = np.array([225,20,20], dtype=float)
        patch = patch*(1-alpha) + red*alpha
        img.paste(Image.fromarray(patch.astype(np.uint8)), (r[0], r[1])); d = ImageDraw.Draw(img)
    # подписи координат в углах клеток (как в реальных приложениях)
    fs = ImageFont.truetype(DEJAVU, int(cell*0.17))
    for k in range(8):
        r = cellrect(k,7); d.text((r[2]-int(cell*0.2), r[1]+3), str(k+1) if flipped is False and False else str(8-k if not flipped else k+1), fill=(90,90,90), font=fs)
        r = cellrect(7,k); d.text((r[0]+4, r[3]-int(cell*0.22)), "abcdefgh"[k if not flipped else 7-k], fill=(90,90,90), font=fs)
    fnt = ImageFont.truetype(font_path, int(cell*scale))
    sw = max(2, int(cell/38))
    for s in range(64):
        pc = b[s]
        i,j = ij(s); r = cellrect(i,j)
        if pc == '.':
            if dots and rnd.random() < dots:   # точка «можно пойти сюда»
                cx, cy, rr = (r[0]+r[2])//2, (r[1]+r[3])//2, int(cell*0.15)
                d.ellipse([cx-rr,cy-rr,cx+rr,cy+rr], fill=(110,110,110))
            continue
        ch = chr(GLYPH[pc.upper()])
        bb = fnt.getbbox(ch, stroke_width=sw)
        tx = (r[0]+r[2])/2 - (bb[0]+bb[2])/2; ty = (r[1]+r[3])/2 - (bb[1]+bb[3])/2
        if pc.isupper(): d.text((tx,ty), ch, font=fnt, fill=(252,252,252), stroke_width=sw, stroke_fill=(35,35,35))
        else:            d.text((tx,ty), ch, font=fnt, fill=(38,38,42), stroke_width=sw, stroke_fill=(10,10,10))
    arr = np.asarray(img).astype(np.int16)
    if noise: arr = arr + np.random.RandomState(1).normal(0, noise, arr.shape).astype(np.int16)
    Image.fromarray(np.clip(arr,0,255).astype(np.uint8)).save(out)

def scenario(name, geo, theme, font, flipped, noise=0, texture=False, dots=0, W=1080, H=2400, moves=GAME, checks=None, scale=0.82):
    os.makedirs(name, exist_ok=True)
    b = from_fen(START); last = None; lines = []
    for k in range(len(moves)+1):
        fn = f"{name}/f{k:02d}.png"
        render(b, geo, theme, font, flipped, last, noise, texture, dots if k>0 else 0, fn, W, H, (checks or {}).get(k), scale)
        lines.append(f"{fn} {''.join(b)}")
        if k < len(moves):
            u = moves[k]; apply(b, u); last = (sq(u[:2]), sq(u[2:4]))
    with open(f"{name}/expected.txt","w") as fh:
        fh.write(f"{geo[0]} {geo[1]} {geo[2]/8.0} {0 if flipped else 1} {W} {H}\n" + "\n".join(lines) + "\n")

GREEN = ((238,238,210),(118,150,86)); BROWN = ((240,217,181),(181,136,99)); BLUE = ((222,227,230),(140,162,173))
FREESERIF = "/usr/share/fonts/truetype/freefont/FreeSerif.ttf"
scenario("A_green", (40,560,1000), GREEN, DEJAVU, False)
scenario("B_brown_flip_noise", (60,700,960), BROWN, DEJAVU, True, noise=2.5)
scenario("C_blue_freeserif", (0,500,1080), BLUE, FREESERIF, False)
scenario("D_texture_dots", (30,640,1020), BROWN, DEJAVU, False, noise=1.5, texture=True, dots=0.12)
scenario("E_small_board", (180,900,720), GREEN, DEJAVU, False)
scenario("F_tablet", (140,300,1000), BROWN, DEJAVU, False, W=1600, H=2560)
scenario("G_check", (40,560,1000), GREEN, DEJAVU, False, checks={7: sq("e1")})
scenario("H_check_brown_flip", (50,600,980), BROWN, FREESERIF, True, noise=2, checks={7: sq("e1")})
scenario("I_big_sprites", (40,560,1000), GREEN, DEJAVU, False, noise=1.5, scale=1.0)
scenario("J_big_flip_small", (40,700,640), BROWN, DEJAVU, True, scale=0.98, W=720, H=1600)
print("готово")
