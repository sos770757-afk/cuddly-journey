#!/bin/sh
# Проверки ядра: шахматная логика, поиск доски, слежение за партией (нужны JDK 17+ и Python с Pillow, numpy).
set -e
cd "$(dirname "$0")"
mkdir -p build
javac -d build ../app/src/main/java/com/chesshint/overlay/core/*.java TestEngine.java TestVision.java
python3 gen.py
java -cp build TestEngine
java -cp build TestVision A_green B_brown_flip_noise C_blue_freeserif D_texture_dots E_small_board F_tablet G_check H_check_brown_flip I_big_sprites J_big_flip_small
