import com.chesshint.overlay.core.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.nio.file.*;
import java.util.*;
import javax.imageio.ImageIO;

/** Полный конвейер на синтетических кадрах: поиск доски → слежение за партией → запуск «с середины» по библиотеке образцов. */
public class TestVision {
    static byte code(char c) {
        if (c == '.') return 0;
        int t = "pnbrqk".indexOf(Character.toLowerCase(c)) + 1;
        return (byte) (Character.isUpperCase(c) ? t : t | 8);
    }
    static byte[] truth(String s) { byte[] b = new byte[64]; for (int i = 0; i < 64; i++) b[i] = code(s.charAt(i)); return b; }

    public static void main(String[] args) throws Exception {
        int totalBad = 0;
        for (String dir : args) {
            List<String> lines = Files.readAllLines(Paths.get(dir, "expected.txt"));
            String[] h = lines.get(0).split(" ");
            float tx = Float.parseFloat(h[0]), ty = Float.parseFloat(h[1]), tc = Float.parseFloat(h[2]);
            Tracker tr = new Tracker();
            Library lib = new Library();
            float thr = 0;
            int bad = 0, n = 0, followed = 0;
            double geoErr = 0;
            List<Vision.Cell[]> allCells = new ArrayList<>();
            List<Recognizer.Obs> allObs = new ArrayList<>();
            List<byte[]> allTruth = new ArrayList<>();
            StringBuilder log = new StringBuilder();
            Vision.Geo geo = null;
            for (int k = 1; k < lines.size(); k++) {
                String[] p = lines.get(k).split(" ");
                if (p.length < 2) continue;
                BufferedImage im = ImageIO.read(new File(p[0]));
                int w = im.getWidth(), hh = im.getHeight();
                int[] px = im.getRGB(0, 0, w, hh, null, 0, w);
                if (geo == null || !Vision.verify(geo, px, w, hh)) geo = Vision.find(px, w, hh);
                if (geo == null) { log.append("  кадр " + (k - 1) + ": доска не найдена\n"); bad++; continue; }
                if (k == 1) geoErr = Math.max(Math.max(Math.abs(geo.x - tx), Math.abs(geo.y - ty)), Math.abs(geo.cell - tc) * 8);
                Vision.Cell[] cells = Vision.cells(geo, px, w, hh);
                Recognizer.Obs o = Recognizer.observe(cells, thr);
                if (o.colorsOk) thr = o.thr;
                byte[] tru = truth(p[1]);
                Tracker.Status st = tr.update(o, cells, lib);
                n++;
                boolean ok = tr.cur != null && tr.cur.samePlacement(tru);
                if (ok) followed++; else { bad++; log.append("  кадр " + (k - 1) + ": " + st + " позиция " + (ok ? "верна" : "НЕВЕРНА") + " фигур=" + o.count + "\n"); }
                if (ok) for (int i = 0; i < 8; i++) for (int j = 0; j < 8; j++) {
                    int pc = tr.cur.b[Recognizer.boardSq(i, j, tr.whiteBottom)];
                    if (pc != 0) lib.learn(cells[i * 8 + j], pc & 7, (pc & 8) == 0);
                }
                allCells.add(cells); allObs.add(o); allTruth.add(tru);
            }
            // запуск «с середины»: новый трекер, позиция известна только по виду фигур (библиотека из первых кадров)
            int midOk = 0, midN = 0;
            Library early = new Library();
            for (int k = 0; k < Math.min(5, allCells.size()); k++) {
                Tracker t0 = new Tracker();
                // восстановим точные позиции первых кадров, чтобы пополнить библиотеку «как в игре»
            }
            for (Library.Ex e : lib.ex) early.ex.add(e);
            for (int k = 6; k < allCells.size(); k += 2) {
                Tracker t2 = new Tracker();
                early.defaultWhiteBottom = true;
                Tracker.Status st = t2.update(allObs.get(k), allCells.get(k), early);
                midN++;
                boolean ok = t2.cur != null && t2.cur.samePlacement(allTruth.get(k));
                if (ok) midOk++; else log.append("  с середины, кадр " + k + ": " + st + (t2.cur == null ? "" : " неверные типы") + "\n");
            }
            System.out.printf("%-22s геометрия %.1fpx, слежение %d/%d, запуск с середины %d/%d%n", dir, geoErr, followed, n, midOk, midN);
            System.out.print(log);
            totalBad += bad + (midN - midOk);
        }
        System.out.println(totalBad == 0 ? "ВСЕ СЦЕНАРИИ ПРОЙДЕНЫ" : "ОШИБОК: " + totalBad);
    }
}
