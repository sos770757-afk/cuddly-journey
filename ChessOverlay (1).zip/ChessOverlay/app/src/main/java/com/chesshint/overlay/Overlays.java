package com.chesshint.overlay;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.media.Image;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

import com.chesshint.overlay.core.Position;

import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Журнал для диагностики: что видит приложение (его можно скопировать кнопкой «Отчёт»). */
final class Diag {
    private static final ArrayDeque<String> LOG = new ArrayDeque<>();
    private static final SimpleDateFormat FMT = new SimpleDateFormat("HH:mm:ss", Locale.US);
    static volatile int frames;
    static volatile String frameInfo = "кадров нет";

    static synchronized void log(String s) {
        LOG.addLast(FMT.format(new Date()) + "  " + s);
        while (LOG.size() > 80) LOG.removeFirst();
        Log.i("ChessHint", s);
    }

    static synchronized String dump() {
        StringBuilder sb = new StringBuilder("Шахматный помощник — отчёт\n").append(frameInfo).append('\n');
        for (String l : LOG) sb.append(l).append('\n');
        return sb.toString();
    }
}

/** Последний кадр экрана: копия байтов RGBA без Bitmap (никаких проблем с прозрачностью и выравниванием строк). */
final class FrameStore {
    private ByteBuffer buf;
    private int w, h, rs, ps;
    volatile long seq;

    synchronized void put(Image img) {
        Image.Plane pl = img.getPlanes()[0];
        ByteBuffer src = pl.getBuffer();
        src.rewind();
        int need = src.remaining();
        if (buf == null || buf.capacity() < need) buf = ByteBuffer.allocateDirect(need);
        ((Buffer) buf).clear();
        buf.put(src);
        w = img.getWidth(); h = img.getHeight(); rs = pl.getRowStride(); ps = pl.getPixelStride();
        seq++;
    }

    synchronized int width() { return w; }
    synchronized int height() { return h; }

    private int px(int x, int y) {
        int i = y * rs + x * ps;
        return 0xFF000000 | ((buf.get(i) & 255) << 16) | ((buf.get(i + 1) & 255) << 8) | (buf.get(i + 2) & 255);
    }

    synchronized boolean ready() { return buf != null && w > 0; }

    synchronized int lumAt(int x, int y) {
        if (buf == null || x < 0 || y < 0 || x >= w || y >= h) return 0;
        int i = y * rs + x * ps;
        return ((buf.get(i) & 255) * 77 + (buf.get(i + 1) & 255) * 150 + (buf.get(i + 2) & 255) * 29) >> 8;
    }

    /** Прямоугольник кадра как ARGB-пиксели. */
    synchronized void roi(int x0, int y0, int rw, int rh, int[] out) {
        for (int y = 0; y < rh; y++) for (int x = 0; x < rw; x++) {
            int X = x0 + x, Y = y0 + y;
            out[y * rw + x] = (X < 0 || Y < 0 || X >= w || Y >= h) ? 0xFF000000 : px(X, Y);
        }
    }

    /** Средняя яркость по сетке точек — чтобы понять, не чёрный ли кадр. */
    synchronized float meanLum() {
        if (buf == null) return -1f;
        float s = 0;
        int n = 0;
        for (int y = h / 20; y < h; y += h / 10 + 1) for (int x = w / 20; x < w; x += w / 10 + 1) { s += lumAt(x, y); n++; }
        return n == 0 ? 0 : s / n;
    }
}

/** Прозрачный слой на весь экран: неоновые стрелки, красные подсветки угроз, шкала оценки и строка статуса. */
final class ArrowView extends View {
    static final class Arrow { float x1, y1, x2, y2, w; int color; }

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG), txt = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final float d;
    private List<Arrow> arrows = new ArrayList<>();
    private List<RectF> boxes = new ArrayList<>();
    private boolean evalOn;
    private String evalText = "", status = "";
    private float evalFrac = 0.5f, evalShown = 0.5f, pulse, grow = 1f;
    private int dot = 0xFF22D3EE;
    private ValueAnimator anim;

    ArrowView(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        txt.setTypeface(Typeface.DEFAULT_BOLD);
        txt.setTextAlign(Paint.Align.CENTER);
    }

    void setHints(List<Arrow> a, List<RectF> b) { arrows = a; boxes = b; grow = 0f; animate(true); }
    void clearHints() { arrows = new ArrayList<>(); boxes = new ArrayList<>(); invalidate(); }
    void setEval(boolean on, String t, float frac) { evalOn = on; evalText = t; evalFrac = frac; animate(true); }
    void setStatus(String s, int dotColor) { status = s == null ? "" : s; dot = dotColor; invalidate(); }

    private void animate(boolean on) {
        invalidate();
        if (!on || anim != null) return;
        anim = ValueAnimator.ofFloat(0f, 1f);
        anim.setDuration(1100);
        anim.setRepeatCount(ValueAnimator.INFINITE);
        anim.setRepeatMode(ValueAnimator.REVERSE);
        anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator va) {
                pulse = (Float) va.getAnimatedValue();
                grow = Math.min(1f, grow + 0.09f);
                evalShown += (evalFrac - evalShown) * 0.2f;
                invalidate();
                if (arrows.isEmpty() && boxes.isEmpty() && Math.abs(evalShown - evalFrac) < 0.004f) { va.cancel(); anim = null; }
            }
        });
        anim.start();
    }

    @Override protected void onDetachedFromWindow() {
        if (anim != null) anim.cancel();
        anim = null;
        super.onDetachedFromWindow();
    }

    @Override protected void onDraw(Canvas c) {
        int[] loc = new int[2];
        getLocationOnScreen(loc);
        c.save();
        c.translate(-loc[0], -loc[1]);
        for (RectF r : boxes) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(0x26FF2D55);
            c.drawRoundRect(r, 6 * d, 6 * d, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(2.2f * d);
            p.setColor(((int) (140 + 90 * pulse) << 24) | 0xFF2D55);
            c.drawRoundRect(r, 6 * d, 6 * d, p);
        }
        for (Arrow a : arrows) drawArrow(c, a);
        c.restore();

        float top = 34 * d, cx = getWidth() / 2f;
        if (evalOn && evalText.length() > 0) {
            float w = getWidth() * 0.58f, h = 22 * d, l = cx - w / 2;
            RectF rr = new RectF(l, top, l + w, top + h);
            path.reset();
            path.addRoundRect(rr, h / 2, h / 2, Path.Direction.CW);
            c.save();
            c.clipPath(path);
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xF0111827);
            c.drawRect(rr, p);
            p.setColor(0xFFF1F5F9);
            c.drawRect(l, top, l + w * evalShown, top + h, p);
            c.restore();
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(1.5f * d);
            p.setColor(0xAA22D3EE);
            c.drawRoundRect(rr, h / 2, h / 2, p);
            txt.setTextSize(13 * d);
            float ty = top + h / 2 + 4.6f * d;
            txt.setStyle(Paint.Style.STROKE);
            txt.setStrokeWidth(3 * d);
            txt.setColor(0xFF000000);
            c.drawText(evalText, cx, ty, txt);
            txt.setStyle(Paint.Style.FILL);
            txt.setColor(0xFFFFFFFF);
            c.drawText(evalText, cx, ty, txt);
            top += h + 6 * d;
        }
        if (status.length() > 0) {
            txt.setTextSize(12.5f * d);
            txt.setStyle(Paint.Style.FILL);
            float tw = txt.measureText(status) + 38 * d, h = 28 * d;
            RectF rr = new RectF(cx - tw / 2, top, cx + tw / 2, top + h);
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xDD0B1220);
            c.drawRoundRect(rr, h / 2, h / 2, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(1.2f * d);
            p.setColor((dot & 0x00FFFFFF) | 0x88000000);
            c.drawRoundRect(rr, h / 2, h / 2, p);
            p.setStyle(Paint.Style.FILL);
            p.setColor(dot);
            c.drawCircle(rr.left + 14 * d, rr.centerY(), 4 * d, p);
            txt.setColor(0xFFFFFFFF);
            c.drawText(status, cx + 8 * d, top + h / 2 + 4.4f * d, txt);
        }
    }

    private void drawArrow(Canvas c, Arrow a) {
        float dx = a.x2 - a.x1, dy = a.y2 - a.y1, len = (float) Math.hypot(dx, dy);
        if (len < 1) return;
        float ux = dx / len, uy = dy / len, L = len * grow;
        float ex = a.x1 + ux * L, ey = a.y1 + uy * L;
        float head = Math.min(L * 0.55f, a.w * 3.3f);
        float bx = ex - ux * head, by = ey - uy * head;
        int base = a.color & 0x00FFFFFF;
        float glow = 0.30f + 0.22f * pulse;
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        for (int g = 3; g >= 1; g--) {
            p.setColor(((int) (255 * glow / g) << 24) | base);
            p.setStrokeWidth(a.w + g * a.w * 0.6f);
            c.drawLine(a.x1, a.y1, bx, by, p);
        }
        p.setColor(a.color);
        p.setStrokeWidth(a.w);
        c.drawLine(a.x1, a.y1, bx, by, p);
        p.setStyle(Paint.Style.FILL);
        path.reset();
        path.moveTo(ex, ey);
        path.lineTo(bx - uy * a.w * 1.45f, by + ux * a.w * 1.45f);
        path.lineTo(bx + uy * a.w * 1.45f, by - ux * a.w * 1.45f);
        path.close();
        c.drawPath(path, p);
        c.drawCircle(a.x1, a.y1, a.w * 0.9f, p);
    }
}

/** Нижняя карточка в стиле тренажёра: мини-доска со стрелкой, шкала оценки, ход текстом и точки-индикатор. */
final class TipCard extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG), t = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final float d;
    private Position pos;
    private boolean whiteBottom = true;
    private int from = -1, to = -1;
    private String move = "", sub = "";
    private float frac = 0.5f, shown = 0.5f, phase;
    private boolean thinking;
    private ValueAnimator anim;

    TipCard(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        t.setTypeface(Typeface.DEFAULT_BOLD);
    }

    void setBoard(Position pp, boolean wb) { pos = pp; whiteBottom = wb; invalidate(); }
    void setMove(String text, int f, int tt) { move = text; from = f; to = tt; invalidate(); }
    void setSub(String s) { sub = s; invalidate(); }
    void setEval(float fr) { frac = fr; run(); }
    void setThinking(boolean on) { thinking = on; run(); }

    private void run() {
        invalidate();
        if (anim != null) return;
        anim = ValueAnimator.ofFloat(0f, 1f);
        anim.setDuration(900);
        anim.setRepeatCount(ValueAnimator.INFINITE);
        anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator va) {
                phase = (Float) va.getAnimatedValue();
                shown += (frac - shown) * 0.2f;
                invalidate();
                if (!thinking && Math.abs(shown - frac) < 0.004f) { va.cancel(); anim = null; }
            }
        });
        anim.start();
    }

    @Override protected void onDetachedFromWindow() {
        if (anim != null) anim.cancel();
        anim = null;
        super.onDetachedFromWindow();
    }

    private float[] sq(int s, float x0, float y0, float cs) {
        int f = s & 7, r = s >> 3, col = whiteBottom ? f : 7 - f, row = whiteBottom ? 7 - r : r;
        return new float[]{x0 + (col + 0.5f) * cs, y0 + (row + 0.5f) * cs};
    }

    @Override protected void onDraw(Canvas c) {
        float W = getWidth(), H = getHeight();
        RectF card = new RectF(1.5f * d, 1.5f * d, W - 1.5f * d, H - 1.5f * d);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xEB0B1220);
        c.drawRoundRect(card, 20 * d, 20 * d, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.4f * d);
        p.setColor(0x6638BDF8);
        c.drawRoundRect(card, 20 * d, 20 * d, p);
        float bs = H - 22 * d, bx = 12 * d, by = 11 * d, cs = bs / 8f;
        for (int i = 0; i < 8; i++) for (int j = 0; j < 8; j++) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(((i + j) & 1) == 0 ? 0xFFDDE3EC : 0xFF7C8BA1);
            c.drawRect(bx + j * cs, by + i * cs, bx + (j + 1) * cs, by + (i + 1) * cs, p);
        }
        if (pos != null) {
            t.setTextAlign(Paint.Align.CENTER);
            t.setTextSize(cs * 0.78f);
            for (int s = 0; s < 64; s++) {
                int pc = pos.b[s];
                if (pc == 0) continue;
                float[] q = sq(s, bx, by, cs);
                boolean w = (pc & 8) == 0;
                p.setStyle(Paint.Style.FILL);
                p.setColor(w ? 0xFFFFFFFF : 0xFF111827);
                c.drawCircle(q[0], q[1], cs * 0.42f, p);
                t.setColor(w ? 0xFF111827 : 0xFFFFFFFF);
                c.drawText(String.valueOf("·PNBRQK".charAt(pc & 7)), q[0], q[1] + cs * 0.27f, t);
            }
        }
        if (from >= 0 && to >= 0) {
            float[] a = sq(from, bx, by, cs), b = sq(to, bx, by, cs);
            float dx = b[0] - a[0], dy = b[1] - a[1], len = (float) Math.hypot(dx, dy);
            if (len > 1) {
                float ux = dx / len, uy = dy / len, hw = cs * 0.2f, hl = cs * 0.62f;
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeCap(Paint.Cap.ROUND);
                p.setStrokeWidth(hw);
                p.setColor(0xFFFF4D6D);
                c.drawLine(a[0], a[1], b[0] - ux * hl * 0.8f, b[1] - uy * hl * 0.8f, p);
                p.setStyle(Paint.Style.FILL);
                path.reset();
                path.moveTo(b[0], b[1]);
                path.lineTo(b[0] - ux * hl - uy * hw * 1.3f, b[1] - uy * hl + ux * hw * 1.3f);
                path.lineTo(b[0] - ux * hl + uy * hw * 1.3f, b[1] - uy * hl - ux * hw * 1.3f);
                path.close();
                c.drawPath(path, p);
            }
        }
        float ex = bx + bs + 7 * d, ew = 5 * d;
        RectF bar = new RectF(ex, by, ex + ew, by + bs);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF1F2937);
        c.drawRoundRect(bar, ew / 2, ew / 2, p);
        p.setColor(0xFFF8FAFC);
        float wh = bs * shown;
        if (whiteBottom) c.drawRoundRect(new RectF(ex, by + bs - wh, ex + ew, by + bs), ew / 2, ew / 2, p);
        else c.drawRoundRect(new RectF(ex, by, ex + ew, by + wh), ew / 2, ew / 2, p);
        float tx = ex + ew + 16 * d, tcx = tx + (W - tx - 12 * d) / 2;
        t.setTextAlign(Paint.Align.CENTER);
        t.setTextSize(Math.min(22 * d, (W - tx - 14 * d) / Math.max(8, move.length()) * 1.9f));
        t.setColor(0xFFFBBF24);
        c.drawText(move, tcx, H / 2f - 2 * d, t);
        t.setTextSize(12 * d);
        t.setColor(0xFFCBD5E1);
        c.drawText(sub, tcx, H / 2f + 16 * d, t);
        int n = 10, active = thinking ? (int) (phase * 9.99f) : -1;
        for (int k = 0; k < n; k++) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(k == active ? 0xFFFBBF24 : (thinking ? 0xFF475569 : (k == 1 ? 0xFFFBBF24 : 0xFF475569)));
            c.drawCircle(tcx + (k - 4.5f) * 11 * d, H - 17 * d, 2.8f * d, p);
        }
    }
}

/** Калибровка доски вручную: передвиньте квадрат и растяните за угол, чтобы линии совпали с клетками. */
final class CalibView extends View {
    interface Listener { void onDone(float x, float y, float size); void onAuto(); void onCancel(); }

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG), t = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float d;
    private float x, y, size;
    private int mode;               // 0 нет, 1 двигаем, 2 тянем за угол
    private float ox, oy;
    private final Listener l;

    CalibView(Context c, float x, float y, float size, Listener l) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        this.x = x; this.y = y; this.size = size; this.l = l;
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextAlign(Paint.Align.CENTER);
    }

    private RectF btn(int k) {
        float w = 96 * d, h = 42 * d, gap = 10 * d, total = 3 * w + 2 * gap, left = (getWidth() - total) / 2f, top = 70 * d;
        return new RectF(left + k * (w + gap), top, left + k * (w + gap) + w, top + h);
    }

    @Override protected void onDraw(Canvas c) {
        int[] loc = new int[2];
        getLocationOnScreen(loc);
        c.save();
        c.translate(-loc[0], -loc[1]);
        float W = getWidth() + loc[0] * 2, H = getHeight() + loc[1] * 2;
        p.setStyle(Paint.Style.FILL);
        p.setColor(0x99000000);
        c.drawRect(0, 0, W, y, p);
        c.drawRect(0, y + size, W, H, p);
        c.drawRect(0, y, x, y + size, p);
        c.drawRect(x + size, y, W, y + size, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.2f * d);
        p.setColor(0xCC22D3EE);
        for (int k = 0; k <= 8; k++) {
            c.drawLine(x + k * size / 8f, y, x + k * size / 8f, y + size, p);
            c.drawLine(x, y + k * size / 8f, x + size, y + k * size / 8f, p);
        }
        p.setStrokeWidth(2.6f * d);
        p.setColor(0xFF34D399);
        c.drawRect(x, y, x + size, y + size, p);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF34D399);
        c.drawCircle(x + size, y + size, 15 * d, p);
        c.restore();
        String[] names = {"Готово", "Авто", "Отмена"};
        int[] cols = {0xFF2563EB, 0xFF334155, 0xFF7F1D1D};
        t.setTextSize(15 * d);
        for (int k = 0; k < 3; k++) {
            RectF r = btn(k);
            p.setStyle(Paint.Style.FILL);
            p.setColor(cols[k]);
            c.drawRoundRect(r, 12 * d, 12 * d, p);
            t.setColor(0xFFFFFFFF);
            c.drawText(names[k], r.centerX(), r.centerY() + 5 * d, t);
        }
        t.setTextSize(13 * d);
        t.setColor(0xFFE2E8F0);
        c.drawText("Совместите сетку с клетками доски: тяните квадрат или зелёный угол", getWidth() / 2f, 130 * d, t);
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        float rx = e.getRawX(), ry = e.getRawY();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                mode = 0;
                if (Math.hypot(rx - (x + size), ry - (y + size)) < 34 * d) mode = 2;
                else if (rx >= x && rx <= x + size && ry >= y && ry <= y + size) mode = 1;
                ox = rx - x; oy = ry - y;
                return true;
            case MotionEvent.ACTION_MOVE:
                if (mode == 1) { x = rx - ox; y = ry - oy; }
                else if (mode == 2) size = Math.max(160 * d, Math.max(rx - x, ry - y));
                invalidate();
                return true;
            case MotionEvent.ACTION_UP:
                if (mode == 0) {
                    float px = e.getX(), py = e.getY();
                    if (btn(0).contains(px, py)) l.onDone(x, y, size);
                    else if (btn(1).contains(px, py)) l.onAuto();
                    else if (btn(2).contains(px, py)) l.onCancel();
                }
                mode = 0;
                return true;
            default:
                return true;
        }
    }
}

/** Редактор позиции: нажатие по клетке меняет фигуру (пусто → пешка → конь → слон → ладья → ферзь → король → пусто). */
final class EditorView extends View {
    final byte[] board = new byte[64];     // в координатах доски (a1=0)
    boolean whiteBottom = true;
    boolean placeWhite = true;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG), t = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float d;

    EditorView(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextAlign(Paint.Align.CENTER);
    }

    @Override protected void onMeasure(int wm, int hm) {
        int w = View.MeasureSpec.getSize(wm);
        setMeasuredDimension(w, w);
    }

    private int squareAt(float px, float py) {
        float cs = getWidth() / 8f;
        int col = (int) (px / cs), row = (int) (py / cs);
        if (col < 0 || col > 7 || row < 0 || row > 7) return -1;
        return whiteBottom ? (7 - row) * 8 + col : row * 8 + (7 - col);
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (e.getActionMasked() != MotionEvent.ACTION_UP) return true;
        int s = squareAt(e.getX(), e.getY());
        if (s < 0) return true;
        int pc = board[s];
        if (pc == 0) board[s] = (byte) (placeWhite ? Position.P : (8 | Position.P));
        else {
            int ty = (pc & 7) + 1, color = pc & 8;
            board[s] = ty > Position.K ? 0 : (byte) (color | ty);
        }
        invalidate();
        return true;
    }

    @Override protected void onDraw(Canvas c) {
        float cs = getWidth() / 8f;
        t.setTextSize(cs * 0.5f);
        for (int row = 0; row < 8; row++) for (int col = 0; col < 8; col++) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(((row + col) & 1) == 0 ? 0xFFDDE3EC : 0xFF7C8BA1);
            c.drawRect(col * cs, row * cs, (col + 1) * cs, (row + 1) * cs, p);
            int s = whiteBottom ? (7 - row) * 8 + col : row * 8 + (7 - col);
            int pc = board[s];
            if (pc == 0) continue;
            boolean w = (pc & 8) == 0;
            p.setColor(w ? 0xFFFFFFFF : 0xFF111827);
            c.drawCircle((col + 0.5f) * cs, (row + 0.5f) * cs, cs * 0.42f, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(1.4f * d);
            p.setColor(0xFF38BDF8);
            c.drawCircle((col + 0.5f) * cs, (row + 0.5f) * cs, cs * 0.42f, p);
            t.setColor(w ? 0xFF111827 : 0xFFFFFFFF);
            c.drawText(String.valueOf("·PNBRQK".charAt(pc & 7)), (col + 0.5f) * cs, (row + 0.5f) * cs + cs * 0.18f, t);
        }
    }
}
