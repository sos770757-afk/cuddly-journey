package com.chesshint.overlay;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.speech.tts.TextToSpeech;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.Toast;

import com.chesshint.overlay.core.Engine;
import com.chesshint.overlay.core.Hints;
import com.chesshint.overlay.core.Library;
import com.chesshint.overlay.core.Position;
import com.chesshint.overlay.core.Recognizer;
import com.chesshint.overlay.core.Tracker;
import com.chesshint.overlay.core.UciAnalyzer;
import com.chesshint.overlay.core.Vision;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Оверлей-тренажёр для партий против ботов. Кадры экрана (MediaProjection) → поиск доски (Vision) → трекер партии →
 * Stockfish → стрелка на доске и/или нижняя карточка с мини-доской. Если автопоиск доски не сработал — калибровка вручную.
 */
public class OverlayService extends Service {
    private static final String CHANNEL = "chesshint";
    private static final String[] LEVELS = {"Лучшие", "Средние", "Слабые"};
    private static final String[] STYLES = {"Стрелка", "Карточка", "Оба"};
    private static final String[] PN = {"", "Пешка", "Конь", "Слон", "Ладья", "Ферзь", "Король"};
    private static final int CYAN = 0xFF22D3EE, GREEN = 0xFF34D399, AMBER = 0xFFFBBF24, RED = 0xFFFF4D6D;

    private Handler main;
    private WindowManager wm;
    private SharedPreferences prefs;
    private float dens;

    // окна
    private ArrowView arrows;
    private TipCard tip;
    private LinearLayout pilot, sheet, editor;
    private CalibView calib;
    private WindowManager.LayoutParams lpPilot, lpSheet, lpEditor, lpTip;
    private TextView tvStatus, tvSub, btnStart;
    private EditorView editView;
    private boolean sheetShown, editorShown;
    private boolean editWhiteToMove = true;
    private TextToSpeech tts;
    private boolean ttsOk;
    private String lastSpoken = "";

    // захват
    private MediaProjection projection;
    private VirtualDisplay vd;
    private ImageReader reader;
    private int sw, sh, dpi;
    private final FrameStore store = new FrameStore();
    private long lastPut;

    // потоки
    private HandlerThread scanThread;
    private Handler scan;
    private final ExecutorService engineExec = Executors.newSingleThreadExecutor();
    private volatile Engine.Analyzer analyzer;
    private volatile boolean destroyed;

    // настройки
    private volatile int tipStyle, level, thinkMs;
    private volatile boolean evalOn, threatsOn, voiceOn;
    private volatile boolean active = true, paused, rescan;

    // состояние сканера (поток scan)
    private Vision.Geo geo, manualGeo;
    private final Tracker tracker = new Tracker();
    private final Library lib = new Library();
    private Vision.Cell[] lastCells;
    private Recognizer.Obs lastObs;
    private float toneThr;
    private int[] roi = new int[0];
    private int roiX, roiY, roiW, roiH;
    private int fpN;
    private int[] fpX, fpY, fp, fpPrev;
    private boolean[] mask;
    private Object maskSrc;
    private long lastChange, lastFind, lastCheck, lastLearn;
    private boolean needAnalysis;
    private int findFails, blackChecks, lastSeqSeen;
    private long lastSeq = -1;
    private boolean libDirty;
    private String lastStatus = "";

    private final Object hintLock = new Object();
    private volatile boolean hintsOn;
    private volatile long hiddenAt;
    private volatile int gen;
    private volatile Shown shown;
    private volatile Cache cache;
    private volatile String evalTextLast = "";
    private volatile float evalFracLast = 0.5f;

    private static final class Shown {
        final List<ArrowView.Arrow> arrows;
        final List<RectF> boxes;
        Shown(List<ArrowView.Arrow> a, List<RectF> b) { arrows = a; boxes = b; }
    }

    private static final class Cache {
        Position pos;
        boolean userWhite;
        List<Engine.Line> lines;
        Hints.Threats th;
        int gen;
        Vision.Geo geo;
        String evalText;
        float evalFrac;
        boolean lowConf;
    }

    // ================================================================== жизненный цикл
    @Override public IBinder onBind(Intent i) { return null; }

    @Override public void onCreate() {
        super.onCreate();
        main = new Handler(Looper.getMainLooper());
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        prefs = getSharedPreferences("chesshint", MODE_PRIVATE);
        dens = getResources().getDisplayMetrics().density;
        tipStyle = prefs.getInt("tip", 2);
        level = prefs.getInt("level", 0);
        thinkMs = prefs.getInt("think", 1000);
        evalOn = prefs.getBoolean("eval", true);
        threatsOn = prefs.getBoolean("threats", false);
        voiceOn = prefs.getBoolean("voice", false);
        tracker.whiteBottom = prefs.getBoolean("wb", true);
        lib.defaultWhiteBottom = tracker.whiteBottom;
        if (prefs.getBoolean("hasManual", false)) {
            manualGeo = Vision.manual(prefs.getFloat("mx", 0), prefs.getFloat("my", 0), prefs.getFloat("ms", 400), null, 0, 0);
        }
        try (InputStream is = getAssets().open("seed.bin")) { lib.load(is); } catch (Throwable t) { Diag.log("seed: " + t); }
        try (InputStream is = new FileInputStream(new File(getFilesDir(), "lib.bin"))) { lib.load(is); } catch (Throwable ignored) { }
        Diag.log("библиотека образцов: " + lib.ex.size());
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || "STOP".equals(intent.getAction())) { stopSelf(); return START_NOT_STICKY; }
        if (projection != null) return START_NOT_STICKY;
        try {
            startForegroundCompat();
            int code = intent.getIntExtra("code", 0);
            Intent data = intent.getParcelableExtra("data");
            MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            projection = mpm.getMediaProjection(code, data);
            projection.registerCallback(new MediaProjection.Callback() {
                @Override public void onStop() { main.post(new Runnable() { @Override public void run() { stopSelf(); } }); }
            }, main);
            scanThread = new HandlerThread("chess-scan");
            scanThread.start();
            scan = new Handler(scanThread.getLooper());
            setupCapture();
            buildUi();
            initEngine();
            scan.postDelayed(tick, 400);
            say("Запускаюсь…", "ищу шахматную доску", CYAN);
            Diag.log("сервис запущен, экран " + sw + "x" + sh);
        } catch (Throwable t) {
            Diag.log("ошибка запуска: " + t);
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    @Override public void onDestroy() {
        destroyed = true;
        super.onDestroy();
        if (scan != null) scan.removeCallbacksAndMessages(null);
        if (scanThread != null) scanThread.quitSafely();
        removeQuiet(sheet); removeQuiet(editor); removeQuiet(calib); removeQuiet(pilot); removeQuiet(tip); removeQuiet(arrows);
        try { if (vd != null) vd.release(); } catch (Throwable ignored) { }
        try { if (reader != null) reader.close(); } catch (Throwable ignored) { }
        try { if (projection != null) projection.stop(); } catch (Throwable ignored) { }
        try { if (tts != null) tts.shutdown(); } catch (Throwable ignored) { }
        saveLib();
        engineExec.shutdownNow();
        Engine.Analyzer a = analyzer;
        if (a != null) a.close();
    }

    private void removeQuiet(View v) { try { if (v != null) wm.removeView(v); } catch (Throwable ignored) { } }

    private void startForegroundCompat() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Шахматный помощник", NotificationManager.IMPORTANCE_LOW));
        Intent stop = new Intent(this, OverlayService.class).setAction("STOP");
        PendingIntent pi = PendingIntent.getService(this, 0, stop, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new Notification.Builder(this, CHANNEL)
                .setContentTitle("Шахматный помощник работает")
                .setContentText("Нажмите, чтобы выключить")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 29) startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        else startForeground(7, n);
    }

    // ================================================================== захват экрана
    private DisplayMetrics realMetrics() {
        Display d = ((DisplayManager) getSystemService(Context.DISPLAY_SERVICE)).getDisplay(Display.DEFAULT_DISPLAY);
        DisplayMetrics dm = new DisplayMetrics();
        d.getRealMetrics(dm);
        return dm;
    }

    private ImageReader newReader(int w, int h) {
        ImageReader r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3);
        r.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
            @Override public void onImageAvailable(ImageReader rd) {
                Image img = null;
                try {
                    img = rd.acquireLatestImage();
                    if (img != null) {
                        long now = SystemClock.uptimeMillis();
                        if (now - lastPut >= 90) { store.put(img); lastPut = now; Diag.frames++; }
                    }
                } catch (Throwable t) {
                    Diag.log("кадр: " + t);
                } finally {
                    if (img != null) img.close();
                }
            }
        }, scan);
        return r;
    }

    private void setupCapture() {
        DisplayMetrics dm = realMetrics();
        sw = dm.widthPixels; sh = dm.heightPixels; dpi = dm.densityDpi;
        reader = newReader(sw, sh);
        vd = projection.createVirtualDisplay("chesshint", sw, sh, dpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, null);
    }

    /** Поворот экрана: меняем размер того же VirtualDisplay (второй createVirtualDisplay на Android 14 запрещён). */
    private void checkSize() {
        DisplayMetrics dm = realMetrics();
        if (dm.widthPixels == sw && dm.heightPixels == sh) return;
        ImageReader nr = newReader(dm.widthPixels, dm.heightPixels);
        vd.resize(dm.widthPixels, dm.heightPixels, dm.densityDpi);
        vd.setSurface(nr.getSurface());
        ImageReader old = reader;
        reader = nr; sw = dm.widthPixels; sh = dm.heightPixels; dpi = dm.densityDpi;
        if (old != null) old.close();
        geo = null; fpPrev = null;
        hideHints();
        Diag.log("поворот экрана: " + sw + "x" + sh);
    }

    // ================================================================== интерфейс
    private int dp(float v) { return (int) (v * dens + 0.5f); }

    private WindowManager.LayoutParams winParams(int w, int h, int flags) {
        return new WindowManager.LayoutParams(w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT);
    }

    private GradientDrawable glass(int cornerDp, int c1, int c2, int strokeColor) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{c1, c2});
        g.setCornerRadius(dp(cornerDp));
        if (strokeColor != 0) g.setStroke(dp(1), strokeColor);
        return g;
    }

    private TextView txt(String t, float sp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(sp);
        v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT_BOLD);
        return v;
    }

    private TextView button(String t, boolean primary, View.OnClickListener l) {
        TextView v = txt(t, 14, 0xFFFFFFFF, true);
        v.setGravity(Gravity.CENTER);
        v.setPadding(dp(8), dp(11), dp(8), dp(11));
        v.setBackground(primary ? glass(13, 0xFF3B82F6, 0xFF1D4ED8, 0x8860A5FA) : glass(13, 0xFF1E293B, 0xFF111827, 0x663B82F6));
        v.setOnClickListener(l);
        return v;
    }

    private LinearLayout.LayoutParams weight(int topDp, int rightDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lp.topMargin = dp(topDp); lp.rightMargin = dp(rightDp);
        return lp;
    }

    private void buildUi() {
        arrows = new ArrowView(this);
        WindowManager.LayoutParams lpA = winParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        lpA.gravity = Gravity.TOP | Gravity.START;
        if (Build.VERSION.SDK_INT >= 28) lpA.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        wm.addView(arrows, lpA);

        tip = new TipCard(this);
        lpTip = winParams(Math.min(sw - dp(16), dp(440)), dp(112), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
        lpTip.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        lpTip.y = dp(10);
        tip.setMove("Жду доску…", -1, -1);
        tip.setSub("откройте партию против бота");
        if (tipStyle != 0) wm.addView(tip, lpTip);

        buildPilot();
        buildSheet();
        buildEditor();
        arrows.setEval(evalOn, evalTextLast, evalFracLast);
    }

    private void buildPilot() {
        pilot = new LinearLayout(this);
        pilot.setOrientation(LinearLayout.VERTICAL);
        pilot.setPadding(dp(14), dp(10), dp(14), dp(12));
        pilot.setBackground(glass(20, 0xF0172036, 0xF00B1220, 0x6638BDF8));
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView grip = txt("⠿", 18, 0xFF64748B, true);
        TextView title = txt("♞ Шахматный помощник", 14.5f, 0xFFFFFFFF, true);
        title.setPadding(dp(8), 0, 0, 0);
        TextView gear = txt("⚙", 17, 0xFFFFFFFF, true);
        gear.setGravity(Gravity.CENTER);
        gear.setBackground(glass(11, 0xFF1E3A5F, 0xFF152A45, 0x8838BDF8));
        gear.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { toggleSheet(); } });
        head.addView(grip);
        head.addView(title, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        head.addView(gear, new LinearLayout.LayoutParams(dp(34), dp(34)));
        pilot.addView(head);
        tvStatus = txt("Запускаюсь…", 13.5f, 0xFFFFFFFF, true);
        tvStatus.setPadding(0, dp(8), 0, 0);
        tvSub = txt("", 12f, 0xFF5EEAD4, false);
        pilot.addView(tvStatus);
        pilot.addView(tvSub);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        btnStart = button("⏸ Пауза", true, new View.OnClickListener() { @Override public void onClick(View v) { toggleActive(); } });
        row.addView(btnStart, weight(10, 8));
        row.addView(button("■ Стоп", false, new View.OnClickListener() { @Override public void onClick(View v) { stopSelf(); } }), weight(10, 0));
        pilot.addView(row);
        lpPilot = winParams(dp(262), WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL);
        lpPilot.gravity = Gravity.TOP | Gravity.START;
        lpPilot.x = prefs.getInt("px", dp(10));
        lpPilot.y = prefs.getInt("py", dp(34));
        wm.addView(pilot, lpPilot);
        head.setOnTouchListener(new View.OnTouchListener() {
            float offX, offY, sx, sy;
            boolean moved;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN: sx = e.getRawX(); sy = e.getRawY(); offX = lpPilot.x - sx; offY = lpPilot.y - sy; moved = false; return true;
                    case MotionEvent.ACTION_MOVE:
                        if (Math.abs(e.getRawX() - sx) + Math.abs(e.getRawY() - sy) > dp(6)) moved = true;
                        if (moved) { lpPilot.x = (int) (e.getRawX() + offX); lpPilot.y = (int) (e.getRawY() + offY); wm.updateViewLayout(pilot, lpPilot); }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (moved) prefs.edit().putInt("px", lpPilot.x).putInt("py", lpPilot.y).apply();
                        return true;
                    default: return true;
                }
            }
        });
    }

    private interface Pick { void on(int i); }

    private void chips(LinearLayout parent, String[] names, int selected, final Pick cb) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        final TextView[] tv = new TextView[names.length];
        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            tv[i] = txt(names[i], 12.5f, 0xFFFFFFFF, true);
            tv[i].setGravity(Gravity.CENTER);
            tv[i].setPadding(dp(4), dp(9), dp(4), dp(9));
            row.addView(tv[i], weight(4, i == names.length - 1 ? 0 : 6));
            tv[i].setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { paintChips(tv, idx); cb.on(idx); }
            });
        }
        paintChips(tv, selected);
        parent.addView(row);
    }

    private void paintChips(TextView[] tv, int sel) {
        for (int i = 0; i < tv.length; i++) {
            boolean on = i == sel;
            tv[i].setBackground(on ? glass(11, 0xFF22D3EE, 0xFF0EA5E9, 0) : glass(11, 0xFF1E293B, 0xFF111827, 0x553B82F6));
            tv[i].setTextColor(on ? 0xFF04121F : 0xFFE2E8F0);
        }
    }

    private Switch toggle(String label, boolean on, CompoundButton.OnCheckedChangeListener l) {
        Switch s = new Switch(this);
        s.setText(label);
        s.setTextColor(0xFFE2E8F0);
        s.setChecked(on);
        s.setPadding(0, dp(8), 0, dp(2));
        s.setOnCheckedChangeListener(l);
        return s;
    }

    private void section(LinearLayout parent, String name) {
        TextView t = txt(name, 11.5f, 0xFF7DD3FC, true);
        t.setPadding(0, dp(12), 0, 0);
        parent.addView(t);
    }

    private TextView thinkLabel;

    private void buildSheet() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14), dp(8), dp(14), dp(14));
        box.addView(txt("Настройки", 15, 0xFFFFFFFF, true));
        section(box, "СТИЛЬ ПОДСКАЗКИ");
        chips(box, STYLES, tipStyle, new Pick() { @Override public void on(int i) { setTipStyle(i); } });
        section(box, "СИЛА И СТИЛЬ ХОДОВ");
        chips(box, LEVELS, level, new Pick() { @Override public void on(int i) { level = i; prefs.edit().putInt("level", i).apply(); republish(); } });
        box.addView(toggle("Шкала оценки (в пешках)", evalOn, new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) {
                evalOn = on; prefs.edit().putBoolean("eval", on).apply();
                arrows.setEval(on, evalTextLast, evalFracLast);
            }
        }));
        box.addView(toggle("Угрозы и опасность (красным)", threatsOn, new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) { threatsOn = on; prefs.edit().putBoolean("threats", on).apply(); rescan = true; }
        }));
        box.addView(toggle("Озвучка хода", voiceOn, new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) { voiceOn = on; prefs.edit().putBoolean("voice", on).apply(); if (on) initTts(); }
        }));
        section(box, "ВРЕМЯ НА РАЗДУМЬЕ");
        LinearLayout st = new LinearLayout(this);
        st.setOrientation(LinearLayout.HORIZONTAL);
        st.setGravity(Gravity.CENTER_VERTICAL);
        TextView minus = button("−", false, new View.OnClickListener() { @Override public void onClick(View v) { setThink(thinkMs - 500); } });
        TextView plus = button("+", false, new View.OnClickListener() { @Override public void onClick(View v) { setThink(thinkMs + 500); } });
        thinkLabel = txt(String.format(Locale.US, "%.1f с", thinkMs / 1000f), 15, 0xFFFFFFFF, true);
        thinkLabel.setGravity(Gravity.CENTER);
        st.addView(minus, new LinearLayout.LayoutParams(dp(46), LinearLayout.LayoutParams.WRAP_CONTENT));
        st.addView(thinkLabel, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        st.addView(plus, new LinearLayout.LayoutParams(dp(46), LinearLayout.LayoutParams.WRAP_CONTENT));
        box.addView(st);
        section(box, "ДОСКА И ПОЗИЦИЯ");
        LinearLayout r1 = new LinearLayout(this), r2 = new LinearLayout(this), r3 = new LinearLayout(this);
        r1.addView(button("↻ Сканировать", true, new View.OnClickListener() { @Override public void onClick(View v) { toggleSheet(); forceRescan(); } }), weight(4, 8));
        r1.addView(button("▦ Калибровка", false, new View.OnClickListener() { @Override public void onClick(View v) { toggleSheet(); startCalib(); } }), weight(4, 0));
        r2.addView(button("✎ Позиция", false, new View.OnClickListener() { @Override public void onClick(View v) { toggleSheet(); showEditor(); } }), weight(8, 8));
        r2.addView(button("⇅ Перевернуть", false, new View.OnClickListener() { @Override public void onClick(View v) { toggleSheet(); flipBoard(); } }), weight(8, 0));
        r3.addView(button("Скопировать отчёт", false, new View.OnClickListener() { @Override public void onClick(View v) { copyReport(); } }), weight(8, 0));
        box.addView(r1); box.addView(r2); box.addView(r3);
        box.addView(txt("Только для тренировки против ботов", 11, 0xFF64748B, false));
        ScrollView sv = new ScrollView(this);
        sv.addView(box);
        sheet = new LinearLayout(this);
        sheet.setBackground(glass(20, 0xF2172036, 0xF20B1220, 0x6638BDF8));
        sheet.addView(sv, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        lpSheet = winParams(dp(290), Math.min((int) (sh * 0.64f), dp(560)), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL);
        lpSheet.gravity = Gravity.TOP | Gravity.START;
    }

    private void buildEditor() {
        editor = new LinearLayout(this);
        editor.setOrientation(LinearLayout.VERTICAL);
        editor.setPadding(dp(14), dp(12), dp(14), dp(14));
        editor.setBackground(glass(20, 0xF5172036, 0xF50B1220, 0x8838BDF8));
        editor.addView(txt("Позиция на доске", 15, 0xFFFFFFFF, true));
        editor.addView(txt("Нажмите по клетке, чтобы сменить фигуру", 11.5f, 0xFF94A3B8, false));
        editView = new EditorView(this);
        LinearLayout.LayoutParams ev = new LinearLayout.LayoutParams(dp(300), dp(300));
        ev.topMargin = dp(8);
        editor.addView(editView, ev);
        LinearLayout c1 = new LinearLayout(this), c2 = new LinearLayout(this), c3 = new LinearLayout(this);
        c1.addView(button("Ставить белые", false, new View.OnClickListener() { @Override public void onClick(View v) { editView.placeWhite = true; } }), weight(8, 8));
        c1.addView(button("Ставить чёрные", false, new View.OnClickListener() { @Override public void onClick(View v) { editView.placeWhite = false; } }), weight(8, 0));
        c2.addView(button("Ход белых", false, new View.OnClickListener() { @Override public void onClick(View v) { editWhiteToMove = true; } }), weight(8, 8));
        c2.addView(button("Ход чёрных", false, new View.OnClickListener() { @Override public void onClick(View v) { editWhiteToMove = false; } }), weight(8, 0));
        c3.addView(button("Применить", true, new View.OnClickListener() { @Override public void onClick(View v) { applyEditor(); } }), weight(10, 8));
        c3.addView(button("Отмена", false, new View.OnClickListener() { @Override public void onClick(View v) { closeEditor(); } }), weight(10, 0));
        editor.addView(c1); editor.addView(c2); editor.addView(c3);
        lpEditor = winParams(dp(330), WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL);
        lpEditor.gravity = Gravity.CENTER;
    }

    private void toggleSheet() {
        if (sheetShown) { removeQuiet(sheet); sheetShown = false; paused = false; return; }
        lpSheet.x = lpPilot.x;
        lpSheet.y = lpPilot.y + dp(150);
        wm.addView(sheet, lpSheet);
        sheetShown = true;
        paused = true;
    }

    private void setTipStyle(int i) {
        boolean hadCard = tipStyle != 0;
        tipStyle = i;
        prefs.edit().putInt("tip", i).apply();
        if (i != 0 && !hadCard) wm.addView(tip, lpTip);
        if (i == 0 && hadCard) removeQuiet(tip);
        republish();
    }

    private void setThink(int ms) {
        thinkMs = Math.max(500, Math.min(5000, ms));
        prefs.edit().putInt("think", thinkMs).apply();
        thinkLabel.setText(String.format(Locale.US, "%.1f с", thinkMs / 1000f));
    }

    private void toggleActive() {
        active = !active;
        btnStart.setText(active ? "⏸ Пауза" : "▶ Старт");
        if (!active) { hideHints(); tip.setMove("Пауза", -1, -1); tip.setSub("нажмите ▶ Старт"); say("Пауза", "подсказки выключены", AMBER); }
        else { rescan = true; say("Продолжаю…", "сканирую доску", CYAN); }
    }

    /** Сообщение в панели. Повторы одного и того же текста не перерисовываются. */
    private void say(final String s, final String sub, final int dot) {
        final String key = s + "|" + sub;
        if (key.equals(lastStatus)) return;
        lastStatus = key;
        main.post(new Runnable() {
            @Override public void run() {
                if (tvStatus == null) return;
                tvStatus.setText(s);
                tvSub.setText(sub);
                tvSub.setTextColor(dot);
            }
        });
    }

    // ================================================================== речь, буфер обмена
    private void initTts() {
        if (tts != null) return;
        tts = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override public void onInit(int status) {
                if (status == TextToSpeech.SUCCESS) { int r = tts.setLanguage(new Locale("ru", "RU")); ttsOk = r >= 0; }
            }
        });
    }

    private void speak(String text) {
        if (!voiceOn || text.equals(lastSpoken)) return;
        lastSpoken = text;
        if (tts == null) { initTts(); return; }
        if (ttsOk) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "hint");
    }

    private void copyReport() {
        final String report = Diag.dump() + "\nгеометрия: " + (geo == null ? "нет" : String.format(Locale.US, "x=%.1f y=%.1f клетка=%.2f качество=%.2f%s", geo.x, geo.y, geo.cell, geo.quality, geo.manual ? " (вручную)" : ""))
                + "\nпозиция: " + (tracker.cur == null ? "нет" : tracker.cur.toFen()) + "\nдвижок: " + (analyzer == null ? "?" : analyzer.name())
                + "\nбиблиотека: " + lib.ex.size() + " образцов\n";
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("report", report));
        Toast.makeText(this, "Отчёт скопирован — вставьте его в чат", Toast.LENGTH_SHORT).show();
    }

    // ================================================================== калибровка и редактор
    private void startCalib() {
        if (calib != null) return;
        paused = true;
        float x, y, size;
        Vision.Geo g = geo != null ? geo : manualGeo;
        if (g != null) { x = g.x; y = g.y; size = g.cell * 8; }
        else { size = Math.min(sw, sh) * 0.9f; x = (sw - size) / 2f; y = sh * 0.3f; }
        calib = new CalibView(this, x, y, size, new CalibView.Listener() {
            @Override public void onDone(final float x, final float y, final float size) {
                prefs.edit().putBoolean("hasManual", true).putFloat("mx", x).putFloat("my", y).putFloat("ms", size).apply();
                finishCalib(Vision.manual(x, y, size, null, 0, 0));
            }
            @Override public void onAuto() { prefs.edit().putBoolean("hasManual", false).apply(); finishCalib(null); }
            @Override public void onCancel() { finishCalib(manualGeo); }
        });
        WindowManager.LayoutParams lp = winParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        lp.gravity = Gravity.TOP | Gravity.START;
        wm.addView(calib, lp);
    }

    private void finishCalib(final Vision.Geo g) {
        removeQuiet(calib);
        calib = null;
        paused = false;
        scan.post(new Runnable() {
            @Override public void run() {
                manualGeo = g;
                geo = null;
                findFails = 0;
                lastFind = 0;
                hintsReset();
                rescan = true;
                Diag.log(g == null ? "калибровка: авто" : "калибровка вручную: " + g.x + "," + g.y + " размер " + g.cell * 8);
            }
        });
    }

    private void showEditor() {
        if (editorShown) return;
        paused = true;
        byte[] b = new byte[64];
        boolean wb = tracker.whiteBottom;
        Position p = tracker.cur;
        if (p != null) System.arraycopy(p.b, 0, b, 0, 64);
        System.arraycopy(b, 0, editView.board, 0, 64);
        editView.whiteBottom = wb;
        editWhiteToMove = p == null ? wb : p.white;
        editView.invalidate();
        wm.addView(editor, lpEditor);
        editorShown = true;
    }

    private void closeEditor() {
        if (!editorShown) return;
        removeQuiet(editor);
        editorShown = false;
        paused = false;
    }

    private void applyEditor() {
        final byte[] b = editView.board.clone();
        final boolean wb = editView.whiteBottom, wtm = editWhiteToMove;
        if (!Tracker.valid(b)) { Toast.makeText(this, "Нужно ровно по одному королю у каждой стороны", Toast.LENGTH_SHORT).show(); return; }
        closeEditor();
        scan.post(new Runnable() {
            @Override public void run() {
                Position p = Position.fromPlacement(b, wtm);
                tracker.set(p, wb);
                // запоминаем вид фигур по исправленной позиции: дальше распознавание будет точным
                Vision.Cell[] cells = lastCells;
                if (cells != null) {
                    for (int i = 0; i < 8; i++) for (int j = 0; j < 8; j++) {
                        int pc = p.b[Recognizer.boardSq(i, j, wb)];
                        if (pc != 0) lib.learn(cells[i * 8 + j], pc & 7, (pc & 8) == 0);
                    }
                    libDirty = true;
                    saveLib();
                }
                Diag.log("позиция задана вручную: " + p.toFen());
                gen++;
                needAnalysis = true;
                lastChange = SystemClock.uptimeMillis() - 400;
            }
        });
    }

    private void flipBoard() {
        scan.post(new Runnable() {
            @Override public void run() {
                tracker.whiteBottom = !tracker.whiteBottom;
                lib.defaultWhiteBottom = tracker.whiteBottom;
                tracker.forget();
                prefs.edit().putBoolean("wb", tracker.whiteBottom).apply();
                rescan = true;
            }
        });
    }

    private void forceRescan() {
        scan.post(new Runnable() {
            @Override public void run() {
                if (geo == null) { lastFind = 0; findFails = 0; }
                rescan = true;
                say("Сканирую…", "читаю доску с экрана", CYAN);
            }
        });
    }

    private void saveLib() {
        if (!libDirty) return;
        libDirty = false;
        try (OutputStream os = new FileOutputStream(new File(getFilesDir(), "lib.bin"))) { lib.save(os); } catch (Throwable t) { Diag.log("lib: " + t); }
    }

    // ================================================================== движок
    private void initEngine() {
        engineExec.execute(new Runnable() {
            @Override public void run() {
                Engine.Analyzer a = null;
                File sf = new File(getApplicationInfo().nativeLibraryDir, "libstockfish.so");
                if (sf.exists()) {
                    try {
                        int th = Math.max(1, Math.min(4, Runtime.getRuntime().availableProcessors() - 1));
                        a = new UciAnalyzer(new String[]{sf.getAbsolutePath()}, "Stockfish", th, 64);
                    } catch (Throwable t) {
                        Diag.log("Stockfish не запустился: " + t);
                    }
                } else {
                    Diag.log("libstockfish.so нет в APK — встроенный движок");
                }
                if (a == null) a = new Engine.Builtin();
                analyzer = a;
                Diag.log("движок: " + a.name());
            }
        });
    }

    private static String moveText(Position pos, String u) {
        int f = Position.sqOf(u.substring(0, 2)), t = Position.sqOf(u.substring(2, 4)), pc = pos.b[f] & 7;
        if (pc == Position.K && Math.abs((t & 7) - (f & 7)) == 2) return (t & 7) > (f & 7) ? "Рокировка O-O" : "Рокировка O-O-O";
        boolean cap = pos.b[t] != 0 || (pc == Position.P && (f & 7) != (t & 7));
        String s = PN[pc] + " " + u.substring(0, 2) + (cap ? "×" : "–") + u.substring(2, 4);
        if (u.length() > 4) s += "=" + ("q".equals(u.substring(4)) ? "Ф" : "r".equals(u.substring(4)) ? "Л" : "b".equals(u.substring(4)) ? "С" : "К");
        return s;
    }

    private void runEngine(final Position pos, final boolean userWhite, final int g0, final Vision.Geo g, final boolean lowConf) {
        Engine.Analyzer an = analyzer;
        if (an == null) an = new Engine.Builtin();
        boolean myTurn = pos.white == userWhite;
        try {
            long t0 = SystemClock.uptimeMillis();
            List<Engine.Line> lines = an.analyze(pos, myTurn ? 6 : 1, myTurn ? thinkMs : Math.min(thinkMs, 400));
            if (g0 != gen || destroyed) return;
            if (lines.isEmpty()) { say(pos.inCheck() ? "Мат" : "Пат", "партия окончена", AMBER); return; }
            Engine.Line top = lines.get(0);
            Hints.Threats th = null;
            if (threatsOn && myTurn) th = Hints.threats(pos, an, top, 350);
            if (g0 != gen || destroyed) return;
            Cache c = new Cache();
            c.pos = pos; c.userWhite = userWhite; c.lines = lines; c.th = th; c.gen = g0; c.geo = g; c.lowConf = lowConf;
            float pawns = Hints.pawnsWhite(top, pos.white);
            c.evalText = Hints.evalText(top, pos.white);
            c.evalFrac = (float) (1.0 / (1.0 + Math.exp(-pawns / 2.5)));
            cache = c;
            Diag.log("анализ " + (SystemClock.uptimeMillis() - t0) + " мс: " + top.move + " " + c.evalText + (lowConf ? " (приблизительная позиция)" : ""));
            publish(c);
        } catch (Throwable t) {
            Diag.log("движок: " + t);
            if (!(an instanceof Engine.Builtin)) {
                analyzer = new Engine.Builtin();
                an.close();
                runEngine(pos, userWhite, g0, g, lowConf);
            }
        }
    }

    private void republish() {
        engineExec.execute(new Runnable() {
            @Override public void run() {
                Cache c = cache;
                if (c != null && c.gen == gen && !destroyed) publish(c);
            }
        });
    }

    private static float[] center(Vision.Geo g, boolean wb, int sq) {
        int f = sq & 7, r = sq >> 3, col = wb ? f : 7 - f, row = wb ? 7 - r : r;
        return new float[]{g.x + (col + 0.5f) * g.cell, g.y + (row + 0.5f) * g.cell};
    }

    private static ArrowView.Arrow arrow(Vision.Geo g, boolean wb, int from, int to, int color) {
        ArrowView.Arrow a = new ArrowView.Arrow();
        float[] p = center(g, wb, from), q = center(g, wb, to);
        a.x1 = p[0]; a.y1 = p[1]; a.x2 = q[0]; a.y2 = q[1];
        a.w = g.cell * 0.12f;
        a.color = color;
        return a;
    }

    private static RectF cellRect(Vision.Geo g, boolean wb, int sq) {
        float[] c = center(g, wb, sq);
        float h = g.cell / 2f;
        return new RectF(c[0] - h, c[1] - h, c[0] + h, c[1] + h);
    }

    private void publish(final Cache c) {
        final boolean myTurn = c.pos.white == c.userWhite;
        final Engine.Line pick = Hints.pick(c.lines, level);
        final boolean arrowMode = tipStyle != 1;
        List<ArrowView.Arrow> as = new ArrayList<>();
        List<RectF> bx = new ArrayList<>();
        int mf = -1, mt = -1;
        String text = null;
        if (myTurn && pick != null && pick.move.length() >= 4) {
            mf = Position.sqOf(pick.move.substring(0, 2));
            mt = Position.sqOf(pick.move.substring(2, 4));
            text = moveText(c.pos, pick.move);
            if (arrowMode) as.add(arrow(c.geo, c.userWhite, mf, mt, c.lowConf ? 0xE6FBBF24 : 0xE634D399));
        }
        if (threatsOn && c.th != null) {
            for (int[] t : c.th.arrows) if (arrowMode) as.add(arrow(c.geo, c.userWhite, t[0], t[1], 0xEEFF4D6D));
            for (int sq : c.th.squares) if (arrowMode) bx.add(cellRect(c.geo, c.userWhite, sq));
        }
        final Shown sh = new Shown(as, bx);
        final int ff = mf, tt = mt;
        final String mtext = text;
        synchronized (hintLock) {
            if (c.gen != gen || destroyed) return;
            shown = sh;
            hintsOn = !as.isEmpty() || !bx.isEmpty();
            evalTextLast = c.evalText;
            evalFracLast = c.evalFrac;
            main.post(new Runnable() {
                @Override public void run() {
                    if (destroyed || !active || arrows == null) return;
                    arrows.setHints(sh.arrows, sh.boxes);
                    arrows.setEval(evalOn, c.evalText, c.evalFrac);
                    tip.setBoard(c.pos, c.userWhite);
                    tip.setEval(c.evalFrac);
                    tip.setThinking(false);
                    if (myTurn && mtext != null) {
                        tip.setMove(mtext, ff, tt);
                        tip.setSub(c.lowConf ? "позиция определена приблизительно" : "оценка " + c.evalText);
                    } else {
                        tip.setMove("Ждём ход соперника", -1, -1);
                        tip.setSub("оценка " + c.evalText);
                    }
                }
            });
        }
        if (myTurn && mtext != null) {
            say("Ваш ход: " + mtext, c.lowConf ? "позиция приблизительная — ⚙ → Позиция" : "оценка " + c.evalText, c.lowConf ? AMBER : GREEN);
            speak(mtext);
        } else {
            say("Ждём ход соперника", "оценка " + c.evalText, CYAN);
        }
    }

    private void hideHints() {
        synchronized (hintLock) {
            hintsOn = false;
            shown = null;
            gen++;
            hiddenAt = SystemClock.uptimeMillis();
            main.post(new Runnable() { @Override public void run() { if (arrows != null) arrows.clearHints(); } });
        }
    }

    /** Сброс позиции и подсказок (например, после смены калибровки). */
    private void hintsReset() {
        tracker.forget();
        hideHints();
    }

    // ================================================================== сканирование (поток scan)
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (destroyed) return;
            try { step(); } catch (Throwable t) { Diag.log("шаг: " + t); }
            Handler h = scan;
            if (!destroyed && h != null) h.postDelayed(this, 120);
        }
    };

    private void step() {
        long now = SystemClock.uptimeMillis();
        if (now - lastCheck > 2000) {
            lastCheck = now;
            checkSize();
            float lum = store.meanLum();
            Diag.frameInfo = "кадров получено: " + Diag.frames + ", размер " + store.width() + "x" + store.height() + ", средняя яркость " + Math.round(lum);
            if (store.ready() && lum >= 0 && lum < 1.5f) {
                if (++blackChecks >= 2) say("Экран приходит чёрным", "приложение защищено от записи экрана", RED);
            } else blackChecks = 0;
            if (!store.ready() && Diag.frames == 0 && now > 6000) say("Нет кадров от записи экрана", "перезапустите помощник", RED);
        }
        if (!active || paused || !store.ready()) return;
        boolean fresh = store.seq != lastSeq;
        lastSeq = store.seq;
        if (geo == null) {
            if (manualGeo != null) { useGeometry(manualGeo.copy()); return; }
            long wait = findFails < 3 ? 900 : (findFails < 8 ? 2500 : 5000);
            if ((fresh || rescan || findFails > 0 || lastFind == 0) && now - lastFind > wait) { rescan = false; lastFind = now; findBoard(now); }
            return;
        }
        if (fresh && fingerprintChanged()) boardChanged(now);
        if (rescan) { rescan = false; boardChanged(now); }
        if (needAnalysis && !hintsOn && now - lastChange >= 380 && now - hiddenAt >= 250) {
            needAnalysis = false;
            analyze();
        } else if (needAnalysis && now - lastChange >= 2500 && !hintsOn) {   // экран постоянно меняется — всё равно смотрим
            needAnalysis = false;
            analyze();
        }
    }

    private void findBoard(long now) {
        int w = store.width(), h = store.height();
        int[] full = new int[w * h];
        store.roi(0, 0, w, h, full);
        long t0 = SystemClock.uptimeMillis();
        Vision.Geo g = Vision.find(full, w, h);
        long ms = SystemClock.uptimeMillis() - t0;
        if (g == null) {
            findFails++;
            Diag.log("доска не найдена (попытка " + findFails + ", " + ms + " мс)");
            if (findFails >= 4) say("Не вижу доску", "откройте партию на весь экран или ⚙ → Калибровка", AMBER);
            else say("Ищу доску…", "попытка " + (findFails + 1), CYAN);
            return;
        }
        findFails = 0;
        Diag.log(String.format(Locale.US, "доска найдена: x=%.1f y=%.1f клетка=%.2f качество=%.2f (%d мс)", g.x, g.y, g.cell, g.quality, ms));
        useGeometry(g);
    }

    private void useGeometry(Vision.Geo g) {
        geo = g;
        int w = store.width(), h = store.height();
        roiX = Math.max(0, (int) Math.floor(g.x) - 4);
        roiY = Math.max(0, (int) Math.floor(g.y) - 4);
        int x2 = Math.min(w, (int) Math.ceil(g.x + 8 * g.cell) + 4), y2 = Math.min(h, (int) Math.ceil(g.y + 8 * g.cell) + 4);
        roiW = Math.max(16, x2 - roiX);
        roiH = Math.max(16, y2 - roiY);
        if (roi.length != roiW * roiH) roi = new int[roiW * roiH];
        int st = Math.max(4, Math.round(g.cell / 12f));
        int nx = (roiW + st - 1) / st, ny = (roiH + st - 1) / st;
        fpN = nx * ny;
        fpX = new int[fpN]; fpY = new int[fpN]; fp = new int[fpN];
        int k = 0;
        for (int y = 0; y < roiH; y += st) for (int x = 0; x < roiW; x += st) { fpX[k] = roiX + x; fpY[k] = roiY + y; k++; }
        fpPrev = null; mask = null; maskSrc = null;
        lastChange = SystemClock.uptimeMillis() - 400;
        needAnalysis = true;
        gen++;
        say("Доска найдена", "читаю позицию…", CYAN);
        final RectF board = new RectF(g.x, g.y, g.x + 8 * g.cell, g.y + 8 * g.cell);
        main.post(new Runnable() { @Override public void run() { warnIfOverlapped(board); } });
    }

    /** Панель не должна закрывать доску: иначе фигуры под ней не видны. */
    private void warnIfOverlapped(RectF board) {
        RectF pr = new RectF(lpPilot.x, lpPilot.y, lpPilot.x + dp(262), lpPilot.y + dp(150));
        if (RectF.intersects(pr, board)) Toast.makeText(this, "Панель закрывает доску — перетащите её за заголовок", Toast.LENGTH_LONG).show();
    }

    private void boardChanged(long now) {
        synchronized (hintLock) {
            gen++;
            if (hintsOn) {
                hintsOn = false;
                shown = null;
                hiddenAt = now;
                main.post(new Runnable() { @Override public void run() { if (arrows != null) arrows.clearHints(); } });
            }
        }
        lastChange = now;
        needAnalysis = true;
    }

    private static boolean nearSeg(float px, float py, ArrowView.Arrow a, float r) {
        float dx = a.x2 - a.x1, dy = a.y2 - a.y1, l2 = dx * dx + dy * dy;
        float t = l2 == 0 ? 0 : ((px - a.x1) * dx + (py - a.y1) * dy) / l2;
        t = Math.max(0f, Math.min(1f, t));
        float qx = a.x1 + t * dx - px, qy = a.y1 + t * dy - py;
        return qx * qx + qy * qy <= r * r;
    }

    private boolean[] buildMask(Shown s) {
        boolean[] m = new boolean[fpN];
        if (s == null) return m;
        for (int k = 0; k < fpN; k++) {
            float x = fpX[k], y = fpY[k];
            boolean hit = false;
            for (RectF r : s.boxes) if (r.contains(x, y)) { hit = true; break; }
            if (!hit) for (ArrowView.Arrow a : s.arrows) if (nearSeg(x, y, a, a.w * 1.7f + 4)) { hit = true; break; }
            m[k] = hit;
        }
        return m;
    }

    /** «Отпечаток» доски: яркость в сетке точек; точки под нашими стрелками не сравниваются. */
    private boolean fingerprintChanged() {
        Shown s = shown;
        if (mask == null || s != maskSrc) { mask = buildMask(s); maskSrc = s; }
        for (int k = 0; k < fpN; k++) fp[k] = store.lumAt(fpX[k], fpY[k]);
        if (fpPrev == null) { fpPrev = fp.clone(); return false; }
        int diff = 0;
        for (int k = 0; k < fpN; k++) if (!mask[k] && Math.abs(fp[k] - fpPrev[k]) > 24) diff++;
        System.arraycopy(fp, 0, fpPrev, 0, fpN);
        return diff > 8;
    }

    private void analyze() {
        store.roi(roiX, roiY, roiW, roiH, roi);
        Vision.Geo lg = geo.copy();
        lg.x -= roiX; lg.y -= roiY;
        if (!geo.manual && !Vision.verify(lg, roi, roiW, roiH)) {
            Diag.log("доска пропала с экрана — ищу заново");
            geo = null; lastFind = 0; findFails = 0;
            tracker.forget();
            main.post(new Runnable() { @Override public void run() { tip.setMove("Жду доску…", -1, -1); tip.setSub("откройте партию против бота"); } });
            say("Ищу доску…", "она ушла с экрана", CYAN);
            return;
        }
        Vision.Cell[] cells = Vision.cells(lg, roi, roiW, roiH);
        Recognizer.Obs o = Recognizer.observe(cells, toneThr);
        if (o.colorsOk) toneThr = o.thr;
        Tracker.Status st = tracker.update(o, cells, lib);
        lastCells = cells; lastObs = o;
        Diag.log("кадр: фигур=" + o.count + " старт=" + o.startLike + " статус=" + st + " цена=" + tracker.lastCost + (tracker.lastMove.isEmpty() ? "" : " ход=" + tracker.lastMove));
        if (st == Tracker.Status.INVALID) { say("Позиции на доске нет", "жду начала партии", CYAN); return; }
        if (st == Tracker.Status.NEED_TYPES || tracker.cur == null) {
            say("Не узнал фигуры", "⚙ → Позиция: поправьте один раз — я запомню", AMBER);
            main.post(new Runnable() { @Override public void run() { tip.setMove("Не узнал фигуры", -1, -1); tip.setSub("⚙ → Позиция"); } });
            return;
        }
        if (prefs.getBoolean("wb", true) != tracker.whiteBottom) { prefs.edit().putBoolean("wb", tracker.whiteBottom).apply(); lib.defaultWhiteBottom = tracker.whiteBottom; }
        long now = SystemClock.uptimeMillis();
        if ((st == Tracker.Status.RESET || st == Tracker.Status.UPDATED) && !tracker.lowConf && tracker.lastCost <= 2 && now - lastLearn > 1500) {
            lastLearn = now;
            int before = lib.ex.size();
            for (int i = 0; i < 8; i++) for (int j = 0; j < 8; j++) {
                int pc = tracker.cur.b[Recognizer.boardSq(i, j, tracker.whiteBottom)];
                if (pc != 0) lib.learn(cells[i * 8 + j], pc & 7, (pc & 8) == 0);
            }
            if (lib.ex.size() != before) { libDirty = true; saveLib(); }
        }
        final Position pos = tracker.cur.copy();
        final boolean userWhite = tracker.whiteBottom, low = tracker.lowConf;
        final int g0 = gen;
        final Vision.Geo g = geo;
        main.post(new Runnable() { @Override public void run() { tip.setThinking(true); tip.setBoard(pos, userWhite); } });
        engineExec.execute(new Runnable() { @Override public void run() { runEngine(pos, userWhite, g0, g, low); } });
    }
}
