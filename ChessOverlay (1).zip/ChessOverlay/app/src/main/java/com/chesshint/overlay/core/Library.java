package com.chesshint.overlay.core;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Библиотека образцов: силуэт фигуры → её тип. Пополняется сама, когда тип известен точно (старт партии, точное отслеживание),
 * и умеет распознавать фигуры при включении помощника посреди партии.
 */
public final class Library implements Recognizer.Typer {
    public static final class Ex {
        public final float[] cov;
        public final byte type;      // 1..6
        public final boolean white;
        Ex(float[] cov, byte type, boolean white) { this.cov = cov; this.type = type; this.white = white; }
    }

    public final List<Ex> ex = new ArrayList<>();
    public boolean defaultWhiteBottom = true;
    public float lastConf;
    private static final int MAGIC = 0x4C494231, CAP = 28;

    public boolean ready() { return ex.size() >= 6; }

    /** Расстояние между силуэтами с допуском на сдвиг в 1 клетку сетки: 0 — совпали, 1 — ничего общего. */
    public static float dist(float[] a, float[] b) {
        int G = Vision.G;
        float best = 9f;
        for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) {
            float s = 0, t = 0;
            for (int y = 0; y < G; y++) {
                int y2 = y + dy;
                for (int x = 0; x < G; x++) {
                    int x2 = x + dx;
                    float va = a[y * G + x], vb = (y2 < 0 || y2 >= G || x2 < 0 || x2 >= G) ? 0f : b[y2 * G + x2];
                    s += Math.abs(va - vb);
                    t += va + vb;
                }
            }
            float d = t < 1e-3f ? 1f : 2f * s / t;
            if (d < best) best = d;
        }
        return best;
    }

    /** Запомнить образец (повторы почти не добавляются). */
    public void learn(Vision.Cell c, int type, boolean white) {
        if (!c.occ || type < 1 || type > 6) return;
        int same = 0;
        for (Ex e : ex) {
            if (e.type != type) continue;
            same++;
            if (dist(c.cov, e.cov) < 0.05f) return;
        }
        if (same >= CAP) return;
        ex.add(new Ex(c.cov.clone(), (byte) type, white));
    }

    /** Лучший тип и расстояние до него; out[0]=расстояние, out[1]=отрыв от второго по типу. */
    public int match(Vision.Cell c, float[] out) {
        float[] dt = new float[7];
        java.util.Arrays.fill(dt, 9f);
        for (Ex e : ex) {
            float d = dist(c.cov, e.cov);
            if (d < dt[e.type]) dt[e.type] = d;
        }
        int best = 0;
        float bd = 9f, sd = 9f;
        for (int t = 1; t <= 6; t++) {
            if (dt[t] < bd) { sd = bd; bd = dt[t]; best = t; } else if (dt[t] < sd) sd = dt[t];
        }
        out[0] = bd; out[1] = sd - bd;
        return best;
    }

    // ------------------------------------------------------------------ Typer
    @Override public Recognizer.Typed classify(Vision.Cell[] cells, Recognizer.Obs o) {
        if (!ready()) return null;
        int[] type = new int[64];
        float[] m = new float[2];
        int unknown = 0;
        float conf = 0;
        int n = 0;
        for (int k = 0; k < 64; k++) {
            if (o.occ[k] == 0) continue;
            n++;
            if (!cells[k].occ) { unknown++; continue; }
            int t = match(cells[k], m);
            if (t == 0 || m[0] > 0.40f) { unknown++; continue; }
            type[k] = t;
            conf += Math.max(0f, 1f - m[0] / 0.4f);
        }
        if (n == 0 || unknown > 3) return null;
        // ориентация: центр белых пешек и чёрных пешек по вертикали
        float wp = 0, bp = 0;
        int nwp = 0, nbp = 0;
        for (int k = 0; k < 64; k++) if (type[k] == Position.P) {
            if (o.occ[k] == 1) { wp += k / 8; nwp++; } else { bp += k / 8; nbp++; }
        }
        boolean wb = defaultWhiteBottom;
        if (nwp > 0 && nbp > 0) wb = wp / nwp > bp / nbp;
        else if (nwp + nbp > 0) { float mean = (wp + bp) / (nwp + nbp); wb = nwp > 0 ? mean >= 3.5f : mean < 3.5f; }
        Recognizer.Typed t = new Recognizer.Typed();
        t.board = new byte[64];
        for (int k = 0; k < 64; k++) {
            if (o.occ[k] == 0) continue;
            int tt = type[k] == 0 ? Position.P : type[k];
            t.board[Recognizer.boardSq(k / 8, k % 8, wb)] = (byte) (o.occ[k] == 1 ? tt : (tt | 8));
        }
        t.whiteBottom = wb;
        t.conf = Math.max(0f, Math.min(1f, conf / n - unknown * 0.1f));
        t.stmCue = o.moverCue == 1 ? 2 : o.moverCue == 2 ? 1 : 0;
        lastConf = t.conf;
        return t;
    }

    // ------------------------------------------------------------------ файл
    public void save(OutputStream os) throws IOException {
        DataOutputStream d = new DataOutputStream(os);
        d.writeInt(MAGIC);
        d.writeInt(ex.size());
        for (Ex e : ex) {
            d.writeByte(e.type); d.writeBoolean(e.white);
            for (float v : e.cov) d.writeByte(Math.round(v * 4f));   // покрытие 0..1 с шагом 0.25 — файл маленький
        }
        d.flush();
    }

    public void load(InputStream is) throws IOException {
        DataInputStream d = new DataInputStream(is);
        if (d.readInt() != MAGIC) throw new IOException("bad library");
        int n = d.readInt();
        for (int i = 0; i < n; i++) {
            byte t = d.readByte();
            boolean w = d.readBoolean();
            float[] cov = new float[Vision.G * Vision.G];
            for (int k = 0; k < cov.length; k++) cov[k] = d.readByte() / 4f;
            ex.add(new Ex(cov, t, w));
        }
    }
}
