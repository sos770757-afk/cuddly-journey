package com.chesshint.overlay.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Результаты анализа и встроенный запасной движок (альфа-бета). Основной движок — Stockfish через UciAnalyzer. */
public final class Engine {
    private Engine() {}

    public static final class Line {
        public String move = "";   // e2e4, e7e8q
        public int cp;             // сантипешки с точки зрения стороны, чей ход
        public int mate;           // 0, либо ходов до мата (минус — матуют нас)
        public int depth;
    }

    public interface Analyzer {
        List<Line> analyze(Position p, int multiPv, int ms) throws Exception;
        String name();
        void close();
    }

    /** Единая шкала для сравнения линий. */
    public static int score(Line l) {
        if (l.mate > 0) return 30000 - l.mate;
        if (l.mate < 0) return -30000 - l.mate;
        return l.cp;
    }

    static final int[] VAL = {0, 100, 320, 330, 500, 900, 0};
    private static final int INF = 1000000, MATE = 100000;

    public static final class Builtin implements Analyzer {
        private long deadline, nodes;
        private boolean stop;

        @Override public String name() { return "встроенный движок"; }
        @Override public void close() {}

        @Override public synchronized List<Line> analyze(Position root, int multiPv, int ms) {
            deadline = System.nanoTime() + ms * 1_000_000L;
            stop = false; nodes = 0;
            List<Line> res = new ArrayList<>();
            int[] mv = root.legal();
            int n = mv.length;
            if (n == 0) return res;
            order(root, mv);
            int[] sc = new int[n];
            int reached = 0;
            for (int i = 0; i < n; i++) { Position q = root.copy(); q.make(mv[i]); sc[i] = -eval(q); }
            for (int d = 1; d <= 14; d++) {
                int[] cur = new int[n];
                Arrays.fill(cur, -INF);
                boolean done = true;
                for (int i = 0; i < n; i++) {
                    int alpha = i >= multiPv ? nth(cur, i, multiPv) : -INF;
                    Position q = root.copy(); q.make(mv[i]);
                    int s = -search(q, d - 1, -INF, -alpha, 1);
                    if (stop) { done = false; break; }
                    cur[i] = s;
                }
                if (!done) break;
                sc = cur; reached = d;
                sortBy(mv, sc);
                if (Math.abs(sc[0]) > MATE - 300) break;
            }
            if (reached == 0) sortBy(mv, sc);
            for (int i = 0; i < Math.min(multiPv, n); i++) res.add(line(Position.uci(mv[i]), sc[i], reached));
            return res;
        }

        private static int nth(int[] a, int cnt, int k) {
            int[] t = Arrays.copyOf(a, cnt);
            Arrays.sort(t);
            return t[cnt - k];
        }

        private static Line line(String mv, int s, int depth) {
            Line l = new Line();
            l.move = mv; l.depth = depth;
            if (s > MATE - 300) { l.mate = (MATE - s + 1) / 2; l.cp = 10000; }
            else if (s < -MATE + 300) { l.mate = -((MATE + s + 1) / 2); l.cp = -10000; }
            else l.cp = s;
            return l;
        }

        private int search(Position p, int depth, int alpha, int beta, int ply) {
            if ((++nodes & 2047) == 0 && System.nanoTime() > deadline) stop = true;
            if (stop) return 0;
            if (p.half >= 100) return 0;
            int ks = p.kingSq(p.white);
            boolean chk = ks >= 0 && p.attacked(ks, !p.white);
            if (chk && ply < 24) depth++;
            if (depth <= 0) return quiesce(p, alpha, beta, ply);
            int[] mv = p.legal();
            if (mv.length == 0) return chk ? -MATE + ply : 0;
            order(p, mv);
            for (int m : mv) {
                Position q = p.copy(); q.make(m);
                int s = -search(q, depth - 1, -beta, -alpha, ply + 1);
                if (stop) return 0;
                if (s >= beta) return beta;
                if (s > alpha) alpha = s;
            }
            return alpha;
        }

        private int quiesce(Position p, int alpha, int beta, int ply) {
            if ((++nodes & 2047) == 0 && System.nanoTime() > deadline) stop = true;
            if (stop) return 0;
            int stand = eval(p);
            if (stand >= beta) return beta;
            if (stand > alpha) alpha = stand;
            if (ply > 40) return alpha;
            int[] buf = new int[320];
            int n = p.gen(buf), c = 0;
            int[] caps = new int[n];
            for (int i = 0; i < n; i++) {
                int m = buf[i];
                if (p.b[Position.to(m)] != 0 || Position.promo(m) != 0
                        || ((p.b[Position.from(m)] & 7) == Position.P && Position.to(m) == p.ep)) caps[c++] = m;
            }
            caps = Arrays.copyOf(caps, c);
            order(p, caps);
            for (int m : caps) {
                Position q = p.copy(); q.make(m);
                int ks = q.kingSq(p.white);
                if (ks >= 0 && q.attacked(ks, !p.white)) continue;
                int s = -quiesce(q, -beta, -alpha, ply + 1);
                if (stop) return 0;
                if (s >= beta) return beta;
                if (s > alpha) alpha = s;
            }
            return alpha;
        }
    }

    static void order(Position p, int[] mv) {
        int n = mv.length;
        int[] key = new int[n];
        for (int i = 0; i < n; i++) {
            int m = mv[i], cap = p.b[Position.to(m)] & 7, pc = p.b[Position.from(m)] & 7, k = 0;
            if (cap != 0) k = 10000 + 10 * VAL[cap] - VAL[pc];
            else if (pc == Position.P && Position.to(m) == p.ep) k = 10900;
            if (Position.promo(m) != 0) k += 9000 + VAL[Position.promo(m)];
            key[i] = k;
        }
        for (int i = 1; i < n; i++) {
            int m = mv[i], k = key[i], j = i - 1;
            while (j >= 0 && key[j] < k) { mv[j + 1] = mv[j]; key[j + 1] = key[j]; j--; }
            mv[j + 1] = m; key[j + 1] = k;
        }
    }

    static void sortBy(int[] mv, int[] sc) {
        for (int i = 1; i < mv.length; i++) {
            int m = mv[i], s = sc[i], j = i - 1;
            while (j >= 0 && sc[j] < s) { mv[j + 1] = mv[j]; sc[j + 1] = sc[j]; j--; }
            mv[j + 1] = m; sc[j + 1] = s;
        }
    }

    /** Статическая оценка с точки зрения стороны, чей ход (сантипешки). */
    static int eval(Position p) {
        int s = 0, mat = 0, wb = 0, bb = 0;
        for (int sq = 0; sq < 64; sq++) {
            int pc = p.b[sq];
            if (pc == 0) continue;
            int t = pc & 7;
            if (t != Position.P && t != Position.K) mat += VAL[t];
        }
        boolean end = mat < 2400;
        for (int sq = 0; sq < 64; sq++) {
            int pc = p.b[sq];
            if (pc == 0) continue;
            boolean w = (pc & 8) == 0;
            int t = pc & 7, r = sq >> 3, f = sq & 7, rr = w ? r : 7 - r;
            int cd = (int) (Math.abs(f - 3.5) + Math.abs(r - 3.5));
            int v = VAL[t];
            switch (t) {
                case 1: v += rr * rr * 2 + (f == 3 || f == 4 ? rr * 3 : 0) - (f == 0 || f == 7 ? 6 : 0); break;
                case 2: v += (7 - cd) * 7 - (rr == 0 ? 10 : 0); break;
                case 3: v += (7 - cd) * 3 - (rr == 0 ? 8 : 0); if (w) wb++; else bb++; break;
                case 4: v += (rr == 6 ? 15 : 0) + (f >= 2 && f <= 5 ? 4 : 0); break;
                case 5: v += 7 - cd; break;
                default:
                    if (end) v += (7 - cd) * 6;
                    else v += (rr == 0 ? 20 : -rr * 12) + (f <= 2 || f >= 6 ? 10 : 0);
            }
            s += w ? v : -v;
        }
        if (wb >= 2) s += 25;
        if (bb >= 2) s -= 25;
        return p.white ? s : -s;
    }
}
