package com.chesshint.overlay.core;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

/** Обёртка над UCI-движком (Stockfish) как внешним процессом. */
public final class UciAnalyzer implements Engine.Analyzer {
    private final Process proc;
    private final BufferedWriter out;
    private final BlockingQueue<String> q = new LinkedBlockingQueue<>();
    private final String label;

    public UciAnalyzer(String[] cmd, String label, int threads, int hashMb) throws Exception {
        this.label = label;
        proc = new ProcessBuilder(cmd).redirectErrorStream(true).start();
        out = new BufferedWriter(new OutputStreamWriter(proc.getOutputStream()));
        Thread t = new Thread(() -> {
            try (BufferedReader r = new BufferedReader(new InputStreamReader(proc.getInputStream()))) {
                String s;
                while ((s = r.readLine()) != null) q.add(s);
            } catch (IOException ignored) { }
            q.add("<eof>");
        }, "uci-reader");
        t.setDaemon(true);
        t.start();
        send("uci");
        if (!waitFor("uciok", 10000)) { close(); throw new IOException("no uciok"); }
        send("setoption name Threads value " + threads);
        send("setoption name Hash value " + hashMb);
        send("isready");
        if (!waitFor("readyok", 10000)) { close(); throw new IOException("no readyok"); }
    }

    private void send(String s) throws IOException { out.write(s); out.write('\n'); out.flush(); }

    private boolean waitFor(String prefix, long ms) throws InterruptedException {
        long end = System.currentTimeMillis() + ms;
        while (true) {
            long left = end - System.currentTimeMillis();
            if (left <= 0) return false;
            String s = q.poll(left, TimeUnit.MILLISECONDS);
            if (s == null || s.equals("<eof>")) return false;
            if (s.startsWith(prefix)) return true;
        }
    }

    @Override public String name() { return label; }

    @Override public synchronized List<Engine.Line> analyze(Position p, int multiPv, int ms) throws Exception {
        q.clear();
        send("setoption name MultiPV value " + multiPv);
        send("position fen " + p.toFen());
        send("go movetime " + ms);
        Map<Integer, Engine.Line> best = new TreeMap<>();
        long end = System.currentTimeMillis() + ms + 5000;
        while (true) {
            long left = end - System.currentTimeMillis();
            String s = left > 0 ? q.poll(left, TimeUnit.MILLISECONDS) : null;
            if (s == null || s.equals("<eof>")) { close(); throw new IOException("engine timeout"); }
            if (s.startsWith("bestmove")) break;
            if (s.startsWith("info ")) parseInfo(s, best);
        }
        return new ArrayList<>(best.values());
    }

    static void parseInfo(String s, Map<Integer, Engine.Line> best) {
        String[] t = s.split(" ");
        int depth = 0, mpv = 1, cp = 0, mate = 0;
        boolean hasScore = false, bound = false;
        String move = null;
        for (int i = 1; i < t.length; i++) {
            try {
                switch (t[i]) {
                    case "depth": depth = Integer.parseInt(t[++i]); break;
                    case "multipv": mpv = Integer.parseInt(t[++i]); break;
                    case "score":
                        if (t[i + 1].equals("cp")) { cp = Integer.parseInt(t[i + 2]); hasScore = true; }
                        else if (t[i + 1].equals("mate")) { mate = Integer.parseInt(t[i + 2]); hasScore = true; }
                        i += 2; break;
                    case "lowerbound": case "upperbound": bound = true; break;
                    case "pv": move = t[i + 1]; i = t.length; break;
                    default: break;
                }
            } catch (RuntimeException e) { return; }
        }
        if (!hasScore || move == null || bound) return;
        Engine.Line old = best.get(mpv);
        if (old != null && old.depth > depth) return;
        Engine.Line l = new Engine.Line();
        l.move = move; l.depth = depth; l.cp = mate != 0 ? (mate > 0 ? 10000 : -10000) : cp; l.mate = mate;
        best.put(mpv, l);
    }

    @Override public void close() {
        try { send("quit"); } catch (Exception ignored) { }
        proc.destroy();
    }
}
