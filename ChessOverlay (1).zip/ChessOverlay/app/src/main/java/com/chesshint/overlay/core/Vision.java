package com.chesshint.overlay.core;

import java.util.Arrays;

/**
 * Компьютерное зрение для шахматной доски на снимке экрана (чистая Java, без Android).
 * 1) find(): доска ищется по решётке пересечений клеток (7x7 «перекрёстков» с шахматным контрастом) — это не зависит
 *    от фигур, подписей и подсветок; затем сетка уточняется по линиям границ на полном разрешении.
 * 2) cells(): для каждой клетки берётся фон по медиане рамки клетки, затем из «непохожего на фон» выделяется силуэт.
 */
public final class Vision {
    private Vision() {}

    public static final int N = 64, G = 32, NG = 16, SG = 12;
    private static final int MARGIN = 3;   // поле у краёв клетки, где соседняя клетка может «просочиться» из-за неточности сетки

    public static final class Geo {
        public float x, y, cell;
        public int light, dark;
        public float quality;
        public boolean manual;
        int refA, refB;   // медианные цвета клеток чётности (0,0) и (0,1)
        public Geo copy() {
            Geo g = new Geo();
            g.x = x; g.y = y; g.cell = cell; g.light = light; g.dark = dark; g.quality = quality; g.manual = manual; g.refA = refA; g.refB = refB;
            return g;
        }
    }

    public static final class Cell {
        public boolean occ;
        public final float[] cov = new float[G * G];     // силуэт в долях клетки
        public final float[] norm = new float[NG * NG];  // силуэт, растянутый по своей рамке
        public float tone;           // яркость внутренности фигуры
        public float bw, bh, cx, cy; // рамка силуэта в долях клетки
        public float frac;           // доля площади клетки под силуэтом
        public int bg;               // цвет фона клетки (медиана рамки)
        public float tint;           // насколько фон отличается от обычного цвета клетки такой чётности
        public boolean tinted;
        public boolean dot;          // маленький круг-подсказка «можно пойти сюда», а не фигура
        public final float[] sig = new float[SG * SG * 3];   // цвет блоков минус фон: не зависит от подсветки клетки
        public float energy;         // насколько клетка в целом отличается от своего фона
        public float ctone;          // яркость центра клетки (запасной признак цвета фигуры)
    }

    public static int lum(int c) { return (((c >> 16) & 255) * 77 + ((c >> 8) & 255) * 150 + (c & 255) * 29) >> 8; }

    static int cdiff(int a, int b) {
        return Math.abs(((a >> 16) & 255) - ((b >> 16) & 255)) + Math.abs(((a >> 8) & 255) - ((b >> 8) & 255)) + Math.abs((a & 255) - (b & 255));
    }

    private static int box(int[] I, int iw, int x, int y, int bw, int bh) {
        return I[(y + bh) * iw + x + bw] - I[y * iw + x + bw] - I[(y + bh) * iw + x] + I[y * iw + x];
    }

    // ================================================================ поиск доски
    private static final int[] ORD = new int[49];
    static { for (int k = 0; k < 49; k++) ORD[k] = (k * 19) % 49; }

    /** Отклик «шахматного перекрёстка»: по диагоналям цвет одинаков, по соседним клеткам — разный. */
    private static float junc(int[] I, int iw, int dw, int dh, float jx, float jy, int r) {
        int x = Math.round(jx), y = Math.round(jy);
        if (x - r < 0 || y - r < 0 || x + r > dw || y + r > dh) return 0f;
        float n = r * r;
        float a = box(I, iw, x - r, y - r, r, r) / n, b = box(I, iw, x, y - r, r, r) / n;
        float c = box(I, iw, x - r, y, r, r) / n, d = box(I, iw, x, y, r, r) / n;
        float cross = Math.min(Math.min(Math.abs(a - b), Math.abs(a - c)), Math.min(Math.abs(d - b), Math.abs(d - c)));
        float diag = Math.max(Math.abs(a - d), Math.abs(b - c));
        return cross - diag;
    }

    private static float evalCand(int[] I, int iw, int dw, int dh, float x0, float y0, float s, float[] js) {
        int r = Math.max(2, Math.round(0.2f * s));
        int early = 0;
        for (int k = 0; k < 49; k++) {
            int idx = ORD[k], i = idx / 7 + 1, j = idx % 7 + 1;
            float v = junc(I, iw, dw, dh, x0 + j * s, y0 + i * s, r);
            js[k] = v;
            if (v >= 10f) early++;
            if (k == 11 && early < 5) return 0f;
        }
        float[] t = js.clone();
        Arrays.sort(t);
        float med = t[24];
        if (med < 10f) return 0f;
        int strong = 0;
        for (float v : js) if (v >= 0.5f * med) strong++;
        return strong < 30 ? 0f : strong * med;
    }

    /** У настоящей доски на её границе нет шахматных перекрёстков (снаружи — не клетки). */
    private static boolean boundaryOk(int[] I, int iw, int dw, int dh, float x0, float y0, float s) {
        int r = Math.max(2, Math.round(0.2f * s));
        float[] v = new float[49];
        int k = 0;
        for (int i = 1; i <= 7; i++) for (int j = 1; j <= 7; j++) v[k++] = junc(I, iw, dw, dh, x0 + j * s, y0 + i * s, r);
        Arrays.sort(v);
        float thr = 0.5f * v[24];
        int strong = 0;
        for (int t = 1; t <= 7; t++) {
            if (junc(I, iw, dw, dh, x0 + t * s, y0, r) >= thr) strong++;
            if (junc(I, iw, dw, dh, x0 + t * s, y0 + 8 * s, r) >= thr) strong++;
            if (junc(I, iw, dw, dh, x0, y0 + t * s, r) >= thr) strong++;
            if (junc(I, iw, dw, dh, x0 + 8 * s, y0 + t * s, r) >= thr) strong++;
        }
        return strong <= 4;
    }

    private static void offer(float[] ts, float[][] tc, int[] cnt, float sc, float x0, float y0, float s) {
        for (int k = 0; k < cnt[0]; k++) {
            if (Math.abs(tc[k][0] - x0) < s * 0.6f && Math.abs(tc[k][1] - y0) < s * 0.6f && Math.abs(tc[k][2] - s) < s * 0.15f) {
                if (sc > ts[k]) { ts[k] = sc; tc[k][0] = x0; tc[k][1] = y0; tc[k][2] = s; }
                return;
            }
        }
        if (cnt[0] < ts.length) { ts[cnt[0]] = sc; tc[cnt[0]][0] = x0; tc[cnt[0]][1] = y0; tc[cnt[0]][2] = s; cnt[0]++; return; }
        int worst = 0;
        for (int k = 1; k < ts.length; k++) if (ts[k] < ts[worst]) worst = k;
        if (sc > ts[worst]) { ts[worst] = sc; tc[worst][0] = x0; tc[worst][1] = y0; tc[worst][2] = s; }
    }

    /** Ищет доску на всём кадре. null — не найдена. Осей-выровненные снимки экрана (без поворота). */
    public static Geo find(int[] px, int w, int h) {
        int f = Math.max(1, Math.round(Math.min(w, h) / 300f));
        int dw = w / f, dh = h / f, iw = dw + 1;
        if (dw < 80 || dh < 80) return null;
        int[] I = new int[iw * (dh + 1)];
        for (int y = 0; y < dh; y++) {
            int rowSum = 0;
            for (int x = 0; x < dw; x++) {
                int sum = 0;
                for (int yy = 0; yy < f; yy++) {
                    int base = (y * f + yy) * w + x * f;
                    for (int xx = 0; xx < f; xx++) sum += lum(px[base + xx]);
                }
                rowSum += sum / (f * f);
                I[(y + 1) * iw + x + 1] = I[y * iw + x + 1] + rowSum;
            }
        }
        int m = Math.min(dw, dh);
        float sMax = m / 8f, sMin = Math.max(4f, m * 0.22f / 8f);
        float[] ts = new float[8];
        float[][] tc = new float[8][3];
        int[] cnt = {0};
        float[] js = new float[49];
        for (float s = sMax; s >= sMin; s -= 0.5f) {
            int bw = Math.round(8 * s);
            for (int y0 = 0; y0 + bw <= dh; y0 += 2)
                for (int x0 = 0; x0 + bw <= dw; x0 += 2) {
                    float sc = evalCand(I, iw, dw, dh, x0, y0, s, js);
                    if (sc > 0) offer(ts, tc, cnt, sc, x0, y0, s);
                }
        }
        Integer[] order = new Integer[cnt[0]];
        for (int k = 0; k < order.length; k++) order[k] = k;
        final float[] fts = ts;
        Arrays.sort(order, (p, q) -> Float.compare(fts[q], fts[p]));
        Geo best = null;
        float bestQ = -1f;
        for (int pass = 0; pass < 2; pass++) {
            for (int idx : order) {
                float x0 = tc[idx][0], y0 = tc[idx][1], s = tc[idx][2];
                if (pass == 0 && !boundaryOk(I, iw, dw, dh, x0, y0, s)) continue;
                Geo g = refine(px, w, h, x0 * f, y0 * f, s * f, f);
                if (!verify(g, px, w, h)) continue;
                g = settle(g, px, w, h);
                if (g != null && g.quality > bestQ + 1e-4f) { best = g; bestQ = g.quality; }
            }
            if (best != null) break;
        }
        return best;
    }

    /** Доля клеток соседнего (за окном) ряда/столбца, цвет которых продолжает шахматный узор. side: 0 сверху, 1 снизу, 2 слева, 3 справа. */
    private static float extFrac(Geo g, int[] px, int w, int h, int side) {
        int good = 0, cw = Math.round(g.cell), tol = Math.max(24, cdiff(g.refA, g.refB) / 2);
        for (int t = 0; t < 8; t++) {
            int i = side == 0 ? -1 : side == 1 ? 8 : t, j = side == 2 ? -1 : side == 3 ? 8 : t;
            int x0 = Math.round(g.x + j * g.cell), y0 = Math.round(g.y + i * g.cell);
            if (x0 < 0 || y0 < 0 || x0 + cw > w || y0 + cw > h) return 0f;
            int bg = ring(px, w, h, x0, y0, cw, cw, null);
            if (cdiff(bg, ((i + j) & 1) == 0 ? g.refA : g.refB) <= tol) good++;
        }
        return good / 8f;
    }

    /** Если узор клеток продолжается за окном — окно сдвинуто: сдвигаем на клетку в эту сторону и проверяем заново. */
    private static Geo settle(Geo g, int[] px, int w, int h) {
        for (int iter = 0; iter < 3; iter++) {
            int side = -1;
            float bestF = 0.75f;
            for (int sd = 0; sd < 4; sd++) { float f = extFrac(g, px, w, h, sd); if (f >= bestF) { bestF = f; side = sd; } }
            if (side < 0) return g;
            Geo n = g.copy();
            if (side == 0) n.y -= g.cell; else if (side == 1) n.y += g.cell; else if (side == 2) n.x -= g.cell; else n.x += g.cell;
            if (!verify(n, px, w, h)) return null;
            g = n;
        }
        for (int sd = 0; sd < 4; sd++) if (extFrac(g, px, w, h, sd) >= 0.75f) return null;
        return g;
    }

    private static float[] comb(float[] e, float p0, float c0, int pad, float cpad) {
        float bestV = -1, bp = p0, bc = c0;
        int n = e.length;
        for (float p = p0 - pad; p <= p0 + pad; p += 0.5f)
            for (float c = c0 - cpad; c <= c0 + cpad; c += 0.05f) {
                float sum = 0;
                boolean ok = true;
                for (int j = 0; j <= 8; j++) {
                    int i = Math.round(p + j * c);
                    if (i < 1 || i >= n - 1) { ok = false; break; }
                    sum += e[i - 1] + e[i] + e[i + 1];
                }
                if (ok && sum > bestV) { bestV = sum; bp = p; bc = c; }
            }
        return new float[]{bp, bc};
    }

    /** Уточнение сетки на полном разрешении: линии границ клеток — это места, где по всей длине резко меняется цвет. */
    private static Geo refine(int[] px, int w, int h, float X0, float Y0, float C0, int f) {
        float S8 = 8 * C0;
        int pad = f + 4;
        Geo g0 = new Geo();
        g0.x = X0; g0.y = Y0; g0.cell = C0;
        int te = verify(g0, px, w, h) ? Math.max(30, cdiff(g0.light, g0.dark) / 2) : 60;
        float[] colE = new float[w + 3], rowE = new float[h + 3];
        int ya = Math.max(1, Math.round(Y0 + 0.06f * S8)), yb = Math.min(h - 1, Math.round(Y0 + 0.94f * S8));
        int xa = Math.max(1, Math.round(X0) - pad - 2), xb = Math.min(w - 1, Math.round(X0 + S8) + pad + 2);
        for (int y = ya; y < yb; y += 2) {
            int row = y * w;
            for (int x = xa; x <= xb; x++) if (cdiff(px[row + x], px[row + x - 1]) > te) colE[x] += 1;
        }
        int xa2 = Math.max(0, Math.round(X0 + 0.06f * S8)), xb2 = Math.min(w, Math.round(X0 + 0.94f * S8));
        int ya2 = Math.max(1, Math.round(Y0) - pad - 2), yb2 = Math.min(h - 1, Math.round(Y0 + S8) + pad + 2);
        for (int y = ya2; y <= yb2; y++) {
            int row = y * w;
            for (int x = xa2; x < xb2; x += 2) if (cdiff(px[row + x], px[row - w + x]) > te) rowE[y] += 1;
        }
        float cpad = f * 0.5f + 1f;
        float[] rx = comb(colE, X0, C0, pad, cpad), ry = comb(rowE, Y0, C0, pad, cpad);
        Geo g = new Geo();
        g.x = rx[0]; g.y = ry[0]; g.cell = (rx[1] + ry[1]) / 2f;
        return g;
    }

    // ================================================================ фон клетки и проверка сетки
    private static int med(int[] hist, int n) {
        int acc = 0, half = (n + 1) / 2;
        for (int v = 0; v < 256; v++) { acc += hist[v]; if (acc >= half) return v; }
        return 0;
    }

    /** Медианный цвет рамки клетки (у крупных фигур центр закрыт, а рамка в основном остаётся фоном). */
    static int ring(int[] px, int w, int h, int x0, int y0, int cw, int ch, int[] devOut) {
        int m = Math.min(cw, ch);
        int inset = Math.max(1, Math.round(m * 0.04f)), rw = Math.max(2, Math.round(m * 0.10f));
        int[] samples = new int[(cw / 2 + 2) * (ch / 2 + 2)];
        int n = 0;
        int[] hr = new int[256], hg = new int[256], hb = new int[256];
        for (int yy = inset; yy < ch - inset; yy += 2) {
            int Y = y0 + yy;
            if (Y < 0 || Y >= h) continue;
            boolean edgeRow = yy < inset + rw || yy >= ch - inset - rw;
            for (int xx = inset; xx < cw - inset; xx += 2) {
                if (!edgeRow && xx >= inset + rw && xx < cw - inset - rw) { xx = Math.max(xx, cw - inset - rw - 2); continue; }
                int X = x0 + xx;
                if (X < 0 || X >= w) continue;
                int c = px[Y * w + X];
                samples[n++] = c;
                hr[(c >> 16) & 255]++; hg[(c >> 8) & 255]++; hb[c & 255]++;
            }
        }
        if (n == 0) { if (devOut != null) devOut[0] = 0; return 0; }
        int mr = med(hr, n), mg = med(hg, n), mb = med(hb, n);
        int med = (mr << 16) | (mg << 8) | mb;
        if (devOut != null) {
            int[] hd = new int[256];
            for (int k = 0; k < n; k++) hd[Math.min(255, cdiff(samples[k], med) / 3)]++;
            devOut[0] = med(hd, n) * 3;
        }
        return med;
    }

    private static int medColor(int[] cols, int count) {
        int[] r = new int[count], g = new int[count], b = new int[count];
        for (int k = 0; k < count; k++) { r[k] = (cols[k] >> 16) & 255; g[k] = (cols[k] >> 8) & 255; b[k] = cols[k] & 255; }
        Arrays.sort(r); Arrays.sort(g); Arrays.sort(b);
        return (r[count / 2] << 16) | (g[count / 2] << 8) | b[count / 2];
    }

    private static int[] cellRect(Geo g, int i, int j) {
        int x0 = Math.round(g.x + j * g.cell), x1 = Math.round(g.x + (j + 1) * g.cell);
        int y0 = Math.round(g.y + i * g.cell), y1 = Math.round(g.y + (i + 1) * g.cell);
        return new int[]{x0, y0, x1 - x0, y1 - y0};
    }

    /** Заполняет light/dark/quality: доля клеток, цвет рамки которых совпадает с «своей» чётностью. */
    public static boolean verify(Geo g, int[] px, int w, int h) {
        g.quality = 0;
        if (!(g.cell > 6) || g.x < -2 || g.y < -2 || g.x + 8 * g.cell > w + 2 || g.y + 8 * g.cell > h + 2) return false;
        int[] bg = new int[64], A = new int[32], B = new int[32];
        int na = 0, nb = 0;
        for (int i = 0; i < 8; i++) for (int j = 0; j < 8; j++) {
            int[] r = cellRect(g, i, j);
            bg[i * 8 + j] = ring(px, w, h, r[0], r[1], r[2], r[3], null);
            if (((i + j) & 1) == 0) A[na++] = bg[i * 8 + j]; else B[nb++] = bg[i * 8 + j];
        }
        int ca = medColor(A, na), cb = medColor(B, nb);
        g.refA = ca; g.refB = cb;
        int con = cdiff(ca, cb);
        boolean aLight = lum(ca) >= lum(cb);
        g.light = aLight ? ca : cb;
        g.dark = aLight ? cb : ca;
        if (con < 30) return false;
        int tol = Math.max(24, con / 2), good = 0;
        for (int i = 0; i < 8; i++) for (int j = 0; j < 8; j++) {
            int ref = ((i + j) & 1) == 0 ? ca : cb;
            if (cdiff(bg[i * 8 + j], ref) <= tol) good++;
        }
        g.quality = good / 64f;
        return g.quality >= 0.7f;
    }

    /** Геометрия, заданная пользователем (калибровка вручную). */
    public static Geo manual(float x, float y, float size, int[] px, int w, int h) {
        Geo g = new Geo();
        g.x = x; g.y = y; g.cell = size / 8f; g.manual = true;
        if (px != null) verify(g, px, w, h);
        return g;
    }

    // ================================================================ разбор клеток
    public static Cell[] cells(Geo g, int[] px, int w, int h) {
        int[] bg = new int[64], dev = new int[64], A = new int[32], B = new int[32], dv = new int[1];
        int[][] rect = new int[64][];
        int na = 0, nb = 0;
        for (int i = 0; i < 8; i++) for (int j = 0; j < 8; j++) {
            int k = i * 8 + j;
            rect[k] = cellRect(g, i, j);
            bg[k] = ring(px, w, h, rect[k][0], rect[k][1], rect[k][2], rect[k][3], dv);
            dev[k] = dv[0];
            if (((i + j) & 1) == 0) A[na++] = bg[k]; else B[nb++] = bg[k];
        }
        int ca = medColor(A, na), cb = medColor(B, nb);
        Cell[] out = new Cell[64];
        for (int i = 0; i < 8; i++) for (int j = 0; j < 8; j++) {
            int k = i * 8 + j;
            Cell c = new Cell();
            c.bg = bg[k];
            c.tint = cdiff(bg[k], ((i + j) & 1) == 0 ? ca : cb);
            c.tinted = c.tint > 40;
            analyze(c, px, w, h, rect[k][0], rect[k][1], rect[k][2], rect[k][3], dev[k], 0);
            if (c.frac > 0.72f) analyze(c, px, w, h, rect[k][0], rect[k][1], rect[k][2], rect[k][3], dev[k], 2);
            if (!c.occ && c.energy >= 18f) analyze(c, px, w, h, rect[k][0], rect[k][1], rect[k][2], rect[k][3], dev[k], 3);
            out[k] = c;
        }
        return out;
    }

    private static boolean flow(boolean grad, boolean[] fg, int[] ar, int[] ag, int[] ab, int k, int k2) {
        if (!grad) return !fg[k2];
        return Math.abs(ar[k] - ar[k2]) + Math.abs(ag[k] - ag[k2]) + Math.abs(ab[k] - ab[k2]) < 30;
    }

    /** mode 0 — обычный; 1 — строже к фону; 2 — по плавности цвета (градиенты: шах, подсветки). */
    static void analyze(Cell cell, int[] px, int w, int h, int x0, int y0, int cw, int ch, int dev, int mode) {
        Arrays.fill(cell.cov, 0f);
        Arrays.fill(cell.norm, 0f);
        cell.occ = false; cell.dot = false; cell.frac = 0; cell.tone = 0; cell.bw = 0; cell.bh = 0; cell.cx = 0; cell.cy = 0;
        if (cw < 8 || ch < 8) return;
        int br = (cell.bg >> 16) & 255, bgn = (cell.bg >> 8) & 255, bb = cell.bg & 255;
        // каждая «корзина» сетки N x N усредняет блок пикселей; пустых корзин не бывает, даже если клетка меньше N пикселей
        int[] sr = new int[N * N], sg = new int[N * N], sb = new int[N * N], cnt = new int[N * N];
        for (int by = 0; by < N; by++) {
            int ya = by * ch / N, yb = Math.max(ya + 1, (by + 1) * ch / N);
            for (int bx = 0; bx < N; bx++) {
                int xa = bx * cw / N, xb = Math.max(xa + 1, (bx + 1) * cw / N);
                int k = by * N + bx, r = 0, g = 0, b = 0, c = 0;
                for (int yy = ya; yy < yb && yy < ch; yy++) {
                    int Y = y0 + yy;
                    if (Y < 0 || Y >= h) continue;
                    for (int xx = xa; xx < xb && xx < cw; xx++) {
                        int X = x0 + xx;
                        if (X < 0 || X >= w) continue;
                        int col = px[Y * w + X];
                        r += (col >> 16) & 255; g += (col >> 8) & 255; b += col & 255; c++;
                    }
                }
                sr[k] = r; sg[k] = g; sb[k] = b; cnt[k] = c;
            }
        }
        // сигнатура клетки: средний (цвет − фон) по блокам SG x SG; по ней видно, менялось ли содержимое клетки
        float en = 0; int enN = 0;
        float[] cl = new float[N * N];
        for (int v = 0; v < SG; v++) for (int u = 0; u < SG; u++) {
            int ya = v * N / SG, yb = (v + 1) * N / SG, xa = u * N / SG, xb = (u + 1) * N / SG;
            float dr = 0, dg = 0, db = 0; int c = 0;
            for (int yy = ya; yy < yb; yy++) for (int xx = xa; xx < xb; xx++) {
                int k = yy * N + xx;
                if (cnt[k] == 0) continue;
                dr += sr[k] / (float) cnt[k] - br; dg += sg[k] / (float) cnt[k] - bgn; db += sb[k] / (float) cnt[k] - bb; c++;
            }
            if (c == 0) c = 1;
            int o = (v * SG + u) * 3;
            cell.sig[o] = dr / c; cell.sig[o + 1] = dg / c; cell.sig[o + 2] = db / c;
            if (v >= 1 && v < SG - 1 && u >= 1 && u < SG - 1) { en += Math.abs(cell.sig[o]) + Math.abs(cell.sig[o + 1]) + Math.abs(cell.sig[o + 2]); enN++; }
        }
        cell.energy = enN == 0 ? 0 : en / enN;
        {
            float[] cv = new float[N * N]; int cn = 0;
            for (int yy = N * 3 / 10; yy < N * 7 / 10; yy++) for (int xx = N * 3 / 10; xx < N * 7 / 10; xx++) {
                int k = yy * N + xx;
                if (cnt[k] == 0) continue;
                cv[cn++] = (sr[k] * 77f / cnt[k] + sg[k] * 150f / cnt[k] + sb[k] * 29f / cnt[k]) / 256f;
            }
            if (cn > 0) { Arrays.sort(cv, 0, cn); cell.ctone = cv[cn / 2]; }
        }
        boolean grad = mode == 2;
        int thr = Math.min(110, Math.max(28, 3 * dev + 14));
        if (mode == 1) thr = Math.min(200, thr * 2);
        boolean[] fg = new boolean[N * N];
        float[] bl = new float[N * N];
        int[] ar = new int[N * N], ag = new int[N * N], ab = new int[N * N];
        for (int k = 0; k < N * N; k++) {
            if (cnt[k] == 0) continue;
            ar[k] = sr[k] / cnt[k]; ag[k] = sg[k] / cnt[k]; ab[k] = sb[k] / cnt[k];
            bl[k] = (ar[k] * 77 + ag[k] * 150 + ab[k] * 29) >> 8;
        }
        if (!grad) for (int y = MARGIN; y < N - MARGIN; y++) for (int x = MARGIN; x < N - MARGIN; x++) {
            int k = y * N + x;
            if (cnt[k] == 0) continue;
            if (Math.abs(ar[k] - br) + Math.abs(ag[k] - bgn) + Math.abs(ab[k] - bb) > thr) fg[k] = true;
            else if ((mode == 0 || mode == 3) && x + 1 < N && y + 1 < N) {
                // контур фигуры (резкий перепад яркости) тоже считаем «не фоном»: белая фигура на светлой клетке замыкается по контуру
                float gm = Math.max(Math.abs(bl[k] - bl[k + 1]), Math.abs(bl[k] - bl[k + N]));
                if (gm > 20f + dev * 0.5f) fg[k] = true;
            }
        }
        if (mode == 3) {
            boolean[] d = fg.clone();
            for (int y = 1; y < N - 1; y++) for (int x = 1; x < N - 1; x++) {
                int k = y * N + x;
                if (fg[k - 1] || fg[k + 1] || fg[k - N] || fg[k + N] || fg[k - N - 1] || fg[k - N + 1] || fg[k + N - 1] || fg[k + N + 1]) d[k] = true;
            }
            fg = d;
        }
        boolean[] reach = new boolean[N * N];
        int[] st = new int[N * N * 2];
        int sp = 0;
        for (int i = 0; i < N; i++) {
            int[] seeds = {i, (N - 1) * N + i, i * N, i * N + N - 1};
            for (int s : seeds) if (!fg[s] && !reach[s]) { reach[s] = true; st[sp++] = s; }
        }
        while (sp > 0) {
            int k = st[--sp], x = k % N, y = k / N;
            if (x > 0 && !reach[k - 1] && flow(grad, fg, ar, ag, ab, k, k - 1)) { reach[k - 1] = true; st[sp++] = k - 1; }
            if (x < N - 1 && !reach[k + 1] && flow(grad, fg, ar, ag, ab, k, k + 1)) { reach[k + 1] = true; st[sp++] = k + 1; }
            if (y > 0 && !reach[k - N] && flow(grad, fg, ar, ag, ab, k, k - N)) { reach[k - N] = true; st[sp++] = k - N; }
            if (y < N - 1 && !reach[k + N] && flow(grad, fg, ar, ag, ab, k, k + N)) { reach[k + N] = true; st[sp++] = k + N; }
        }
        boolean[] sil = new boolean[N * N];
        for (int k = 0; k < N * N; k++) sil[k] = !reach[k];
        // самая большая связная область: подписи, точки-подсказки и пр. отбрасываются
        int[] lab = new int[N * N];
        int bestLab = 0, bestSize = 0, nl = 0;
        for (int s0 = 0; s0 < N * N; s0++) {
            if (!sil[s0] || lab[s0] != 0) continue;
            nl++;
            int size = 0, cx0 = N, cx1 = -1, cy0 = N, cy1 = -1;
            sp = 0; st[sp++] = s0; lab[s0] = nl;
            while (sp > 0) {
                int k = st[--sp], x = k % N, y = k / N;
                size++;
                cx0 = Math.min(cx0, x); cx1 = Math.max(cx1, x); cy0 = Math.min(cy0, y); cy1 = Math.max(cy1, y);
                for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) {
                    int xx = x + dx, yy = y + dy;
                    if (xx < 0 || yy < 0 || xx >= N || yy >= N) continue;
                    int k2 = yy * N + xx;
                    if (sil[k2] && lab[k2] == 0) { lab[k2] = nl; st[sp++] = k2; }
                }
            }
            boolean thin = Math.min(cx1 - cx0 + 1, cy1 - cy0 + 1) < 0.14f * N;
            if (size > bestSize && !thin) { bestSize = size; bestLab = nl; }
        }
        int minx = N, maxx = -1, miny = N, maxy = -1;
        for (int k = 0; k < N * N; k++) {
            sil[k] = bestLab != 0 && lab[k] == bestLab;
            if (sil[k]) { int x = k % N, y = k / N; minx = Math.min(minx, x); maxx = Math.max(maxx, x); miny = Math.min(miny, y); maxy = Math.max(maxy, y); }
        }
        cell.frac = bestSize / (float) (N * N);
        if (bestSize == 0) return;
        int bwb = maxx - minx + 1, bhb = maxy - miny + 1;
        cell.bw = bwb / (float) N; cell.bh = bhb / (float) N;
        cell.cx = (minx + maxx + 1) / (2f * N); cell.cy = (miny + maxy + 1) / (2f * N);
        float fill = bestSize / (float) (bwb * bhb);
        boolean dot = cell.bw < 0.46f && cell.bh < 0.46f && fill > 0.70f && fill < 0.88f && Math.abs(cell.bw - cell.bh) < 0.10f;
        cell.dot = dot;
        cell.occ = cell.frac >= 0.09f && cell.bh >= 0.30f && cell.bw >= 0.18f && !dot;
        if (!cell.occ) return;
        boolean[] in = sil.clone();
        for (int it = 0; it < 2; it++) {
            boolean[] nx = new boolean[N * N];
            for (int y = 1; y < N - 1; y++) for (int x = 1; x < N - 1; x++) {
                int k = y * N + x;
                nx[k] = in[k] && in[k - 1] && in[k + 1] && in[k - N] && in[k + N];
            }
            in = nx;
        }
        float[] tv = new float[bestSize];
        int tn = 0;
        for (int k = 0; k < N * N; k++) if (in[k]) tv[tn++] = bl[k];
        if (tn < 8) { tn = 0; for (int k = 0; k < N * N; k++) if (sil[k]) tv[tn++] = bl[k]; }
        Arrays.sort(tv, 0, tn);
        cell.tone = tv[tn / 2];
        for (int gy = 0; gy < G; gy++) for (int gx = 0; gx < G; gx++) {
            int c = 0;
            for (int dy = 0; dy < 2; dy++) for (int dx = 0; dx < 2; dx++) if (sil[(2 * gy + dy) * N + 2 * gx + dx]) c++;
            cell.cov[gy * G + gx] = c / 4f;
        }
        for (int v = 0; v < NG; v++) for (int u = 0; u < NG; u++) {
            int ya = miny + v * bhb / NG, yb = Math.max(ya + 1, miny + (v + 1) * bhb / NG);
            int xa = minx + u * bwb / NG, xb = Math.max(xa + 1, minx + (u + 1) * bwb / NG);
            int c = 0, tot = 0;
            for (int yy = ya; yy < yb && yy <= maxy; yy++) for (int xx = xa; xx < xb && xx <= maxx; xx++) { tot++; if (sil[yy * N + xx]) c++; }
            cell.norm[v * NG + u] = tot == 0 ? 0f : c / (float) tot;
        }
    }
}
