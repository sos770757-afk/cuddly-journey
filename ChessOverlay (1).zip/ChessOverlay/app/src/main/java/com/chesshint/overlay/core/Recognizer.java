package com.chesshint.overlay.core;

import java.util.Arrays;

/** Разбор кадра: где стоят фигуры, какого они цвета, что изменилось, где подсвечен последний ход. Типы фигур — см. Typer. */
public final class Recognizer {
    private Recognizer() {}

    public static final float ENERGY_OCC = 18f;   // клетка заметно отличается от фона — там что-то стоит

    public static final class Obs {
        public final byte[] occ = new byte[64];    // порядок картинки (i*8+j): 0 пусто, 1 светлая фигура, 2 тёмная
        public int count;
        public boolean colorsOk;
        public float thr;                          // порог яркости светлых/тёмных фигур
        public boolean startLike;                  // вид стартовой позиции
        public boolean startWhiteBottom;           // светлые внизу (если startLike)
        public int moverCue;                       // 0 нет, 1 только что ходили светлые, 2 — тёмные (по подсвеченным клеткам)
    }

    /** Определяет типы фигур, когда истории партии нет (включили помощник посреди игры). */
    public interface Typer {
        Typed classify(Vision.Cell[] cells, Obs o);
    }

    public static final class Typed {
        public byte[] board;          // фигуры в координатах доски (a1=0), 0 — пусто
        public boolean whiteBottom;
        public float conf;            // 0..1
        public int stmCue;            // 0 неизвестно, 1 ходят белые, 2 чёрные
    }

    static boolean occupied(Vision.Cell c) { return c.occ || (c.energy >= ENERGY_OCC && !c.dot); }

    static float toneOf(Vision.Cell c) { return c.occ ? c.tone : c.ctone; }

    public static Obs observe(Vision.Cell[] cells, float prevThr) {
        Obs o = new Obs();
        float lo = 1e9f, hi = -1f;
        int n = 0;
        for (Vision.Cell c : cells) if (occupied(c)) { float t = toneOf(c); lo = Math.min(lo, t); hi = Math.max(hi, t); n++; }
        o.count = n;
        if (n < 2) return o;
        float c1 = lo, c2 = hi;
        for (int it = 0; it < 12; it++) {
            float s1 = 0, s2 = 0;
            int n1 = 0, n2 = 0;
            for (Vision.Cell c : cells) if (occupied(c)) {
                float t = toneOf(c);
                if (Math.abs(t - c1) <= Math.abs(t - c2)) { s1 += t; n1++; } else { s2 += t; n2++; }
            }
            if (n1 > 0) c1 = s1 / n1;
            if (n2 > 0) c2 = s2 / n2;
        }
        o.thr = (c1 + c2) / 2f;
        o.colorsOk = c2 - c1 >= 40f;
        if (!o.colorsOk && prevThr > 0) { o.thr = prevThr; o.colorsOk = true; }
        for (int k = 0; k < 64; k++) o.occ[k] = !occupied(cells[k]) ? 0 : (byte) (toneOf(cells[k]) >= o.thr ? 1 : 2);
        o.startLike = startLike(o);
        o.moverCue = moverCue(cells, o);
        return o;
    }

    private static boolean startLike(Obs o) {
        if (!o.colorsOk) return false;
        int topOcc = 0, botOcc = 0, midOcc = 0, topLight = 0, botLight = 0;
        for (int i = 0; i < 8; i++) for (int j = 0; j < 8; j++) {
            int v = o.occ[i * 8 + j];
            if (i <= 1) { if (v != 0) { topOcc++; if (v == 1) topLight++; } }
            else if (i >= 6) { if (v != 0) { botOcc++; if (v == 1) botLight++; } }
            else if (v != 0) midOcc++;
        }
        if (topOcc < 14 || botOcc < 14 || midOcc != 0) return false;
        boolean topIsLight = topLight * 2 > topOcc, botIsLight = botLight * 2 > botOcc;
        if (topIsLight == botIsLight) return false;
        int wrong = (topIsLight ? topOcc - topLight : topLight) + (botIsLight ? botOcc - botLight : botLight);
        if (wrong > 3) return false;
        o.startWhiteBottom = botIsLight;
        return true;
    }

    /** По двум подсвеченным клеткам (последний ход): если одна пуста, а на другой фигура — ходил её цвет. */
    private static int moverCue(Vision.Cell[] cells, Obs o) {
        int a = -1, b = -1, cnt = 0;
        for (int k = 0; k < 64; k++) if (cells[k].tinted) { cnt++; if (a < 0) a = k; else if (b < 0) b = k; }
        if (cnt != 2) return 0;
        boolean oa = o.occ[a] != 0, ob = o.occ[b] != 0;
        if (oa == ob) return 0;
        return o.occ[oa ? a : b];
    }

    /** Какие клетки поменяли содержимое между двумя разборами (по сигнатурам «цвет минус фон»; подсветки не мешают). */
    public static boolean[] changed(Vision.Cell[] prev, Vision.Cell[] cur) {
        boolean[] ch = new boolean[64];
        if (prev == null) return ch;
        for (int k = 0; k < 64; k++) {
            float d = 0;
            int n = 0;
            for (int v = 1; v < Vision.SG - 1; v++) for (int u = 1; u < Vision.SG - 1; u++) {
                int o = (v * Vision.SG + u) * 3;
                d += Math.abs(prev[k].sig[o] - cur[k].sig[o]) + Math.abs(prev[k].sig[o + 1] - cur[k].sig[o + 1]) + Math.abs(prev[k].sig[o + 2] - cur[k].sig[o + 2]);
                n++;
            }
            ch[k] = d / n > 14f;
        }
        return ch;
    }

    public static int boardSq(int i, int j, boolean whiteBottom) { return whiteBottom ? (7 - i) * 8 + j : i * 8 + (7 - j); }
}
