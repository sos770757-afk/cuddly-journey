package com.chesshint.overlay.core;

import java.util.Arrays;

/**
 * Следит за партией. Ходы определяются не по распознаванию вида фигур, а по тому, какие клетки изменились и какие заняты:
 * подбирается цепочка легальных ходов (до 3 полуходов), лучше всего объясняющая кадр. Ошибки распознавания отдельных
 * клеток не ломают партию. Типы фигур нужны только при первой расстановке (стартовая позиция известна сама).
 */
public final class Tracker {
    public enum Status { SAME, UPDATED, RESET, NEED_TYPES, INVALID }

    public Position cur;                   // null — позиция неизвестна
    public volatile boolean whiteBottom = true;
    public boolean lowConf;                // типы фигур определены по догадке (не по стартовой позиции)
    public int lastCost;                   // диагностика: «цена» принятого решения
    public String lastMove = "";           // последний замеченный ход (uci), для диагностики
    private boolean stmKnown;
    private Vision.Cell[] prevCells;

    private static byte occOf(int pc) { return (byte) (pc == 0 ? 0 : ((pc & 8) == 0 ? 1 : 2)); }

    private static boolean[] changedBoard(boolean[] chImg, boolean wb) {
        boolean[] r = new boolean[64];
        for (int i = 0; i < 8; i++) for (int j = 0; j < 8; j++) r[Recognizer.boardSq(i, j, wb)] = chImg[i * 8 + j];
        return r;
    }

    private static byte[] occBoard(Recognizer.Obs o, boolean wb) {
        byte[] r = new byte[64];
        for (int i = 0; i < 8; i++) for (int j = 0; j < 8; j++) r[Recognizer.boardSq(i, j, wb)] = o.occ[i * 8 + j];
        return r;
    }

    /** «Цена» гипотезы: несовпадения занятости (1) и изменившихся клеток (2). */
    private static int cost(Position prev, Position p, byte[] occ, boolean[] chg, boolean haveChg) {
        int c = 0;
        for (int sq = 0; sq < 64; sq++) {
            if (occOf(p.b[sq]) != occ[sq]) c += 1;
            if (haveChg && (prev.b[sq] != p.b[sq]) != chg[sq]) c += 2;
        }
        return c;
    }

    private static final class Best { Position pos; int cost = Integer.MAX_VALUE, c0; int plies; String moves = ""; }

    private static void search(Position start, Position p, int depth, int plies, String moves, byte[] occ, boolean[] chg, boolean haveChg, Best b) {
        for (int m : p.legal()) {
            Position q = p.copy();
            q.make(m);
            String mv = moves + (moves.isEmpty() ? "" : " ") + Position.uci(m);
            int c = cost(start, q, occ, chg, haveChg);
            if (c < b.cost || (c == b.cost && plies + 1 < b.plies)) { b.cost = c; b.pos = q; b.plies = plies + 1; b.moves = mv; }
            if (depth > 1) search(start, q, depth - 1, plies + 1, mv, occ, chg, haveChg, b);
        }
    }

    private Best bestFor(Position base, Recognizer.Obs o, Vision.Cell[] cells, boolean wb, int maxDepth, boolean useChg) {
        byte[] occ = occBoard(o, wb);
        boolean haveChg = useChg && prevCells != null;
        boolean[] chg = haveChg ? changedBoard(Recognizer.changed(prevCells, cells), wb) : new boolean[64];
        Best best = new Best();
        best.cost = cost(base, base, occ, chg, haveChg);   // 0 полуходов
        best.pos = base;
        best.plies = 0;
        int c0 = best.cost;
        for (int depth = 1; depth <= maxDepth; depth++) {
            Best b = new Best();
            search(base, base, depth, 0, "", occ, chg, haveChg, b);
            if (b.pos != null && b.cost < best.cost) best = b;
            if (best.cost <= 4 && best.cost + 3 <= c0) break;   // уже хорошее объяснение — глубже не ищем
        }
        best.c0 = c0;
        return best;
    }

    private Status follow(Position base, Recognizer.Obs o, Vision.Cell[] cells, boolean wb, boolean commit) {
        Best best = bestFor(base, o, cells, wb, 3, true);
        int c0 = best.c0;
        // кадр без изменений (или шум), либо найден ход
        if (c0 <= 6 && c0 <= best.cost + 1) { if (commit) lastCost = c0; return Status.SAME; }
        if (best.plies > 0 && best.cost <= 8 && best.cost + 3 <= c0) {
            if (commit) { cur = best.pos; lastCost = best.cost; lastMove = best.moves; }
            return Status.UPDATED;
        }
        return null;
    }

    /** Позиция в начале партии (1–4 полухода от старта) определяется точно: типы фигур известны без распознавания внешнего вида. */
    private boolean nearStart(Recognizer.Obs o, Vision.Cell[] cells) {
        if (o.count < 28 || o.count > 32) return false;
        Best bw = bestFor(Position.start(), o, cells, true, 4, false), bb = bestFor(Position.start(), o, cells, false, 4, false);
        boolean wb = bw.cost <= bb.cost;
        Best b = wb ? bw : bb;
        if (b.cost > 3 || b.plies == 0 || b.plies > 4) return false;
        if (Math.abs(bw.cost - bb.cost) < 2) return false;      // ориентацию не определить — не гадаем
        cur = b.pos; whiteBottom = wb; stmKnown = true; lowConf = false; lastCost = b.cost; lastMove = b.moves;
        return true;
    }

    /** Обновить состояние по новому разбору кадра. typer нужен лишь когда позиции ещё нет и это не стартовая расстановка. */
    public Status update(Recognizer.Obs o, Vision.Cell[] cells, Recognizer.Typer typer) {
        if (o.count < 2 || o.count > 32 || !o.colorsOk) return Status.INVALID;
        Status st = null;
        if (cur != null) {
            st = follow(cur, o, cells, whiteBottom, true);
            if (st == null && !stmKnown) {          // очередь хода могла быть угадана неверно
                Position fl = cur.copy();
                fl.white = !fl.white;
                fl.ep = -1;
                Status s2 = follow(fl, o, cells, whiteBottom, false);
                if (s2 != null) { cur = fl; st = follow(cur, o, cells, whiteBottom, true); }
            }
            if (st == null) {                       // возможно, доску перевернули в приложении
                Status s3 = follow(cur, o, cells, !whiteBottom, false);
                if (s3 != null) { whiteBottom = !whiteBottom; st = follow(cur, o, cells, whiteBottom, true); }
            }
            if (st != null) { if (st == Status.UPDATED) stmKnown = true; prevCells = cells; return st; }
        }
        if (o.startLike) {
            cur = Position.start();
            whiteBottom = o.startWhiteBottom;
            stmKnown = true;
            lowConf = false;
            prevCells = cells;
            lastMove = "";
            return Status.RESET;
        }
        if (nearStart(o, cells)) { prevCells = cells; return Status.RESET; }
        if (typer == null) { prevCells = cells; return Status.NEED_TYPES; }
        Recognizer.Typed t = typer.classify(cells, o);
        if (t == null || t.board == null || !valid(t.board)) { prevCells = cells; return Status.NEED_TYPES; }
        whiteBottom = t.whiteBottom;
        Position p = Position.fromPlacement(t.board, whiteBottom);   // по умолчанию ходит тот, кто внизу (игрок)
        if (t.stmCue != 0) p.white = t.stmCue == 1;
        int ks = p.kingSq(!p.white);
        if (ks >= 0 && p.attacked(ks, p.white)) p.white = !p.white;
        cur = p;
        stmKnown = t.stmCue != 0;
        lowConf = true;
        prevCells = cells;
        lastMove = "";
        return Status.RESET;
    }

    /** Принять позицию, заданную вручную (редактор). */
    public void set(Position p, boolean wb) { cur = p; whiteBottom = wb; stmKnown = true; lowConf = false; prevCells = null; lastMove = ""; }

    public void forget() { cur = null; prevCells = null; stmKnown = false; lowConf = false; }

    public static boolean valid(byte[] b) {
        int wk = 0, bk = 0, wp = 0, bp = 0, wn = 0, bn = 0, k1 = -1, k2 = -1;
        for (int i = 0; i < 64; i++) {
            int pc = b[i];
            if (pc == 0) continue;
            boolean w = (pc & 8) == 0;
            int t = pc & 7;
            if (t == Position.K) { if (w) { wk++; k1 = i; } else { bk++; k2 = i; } }
            if (t == Position.P) { if (i < 8 || i >= 56) return false; if (w) wp++; else bp++; }
            if (w) wn++; else bn++;
        }
        if (wk != 1 || bk != 1 || wp > 8 || bp > 8 || wn > 16 || bn > 16) return false;
        return Math.abs((k1 & 7) - (k2 & 7)) > 1 || Math.abs((k1 >> 3) - (k2 >> 3)) > 1;
    }
}
