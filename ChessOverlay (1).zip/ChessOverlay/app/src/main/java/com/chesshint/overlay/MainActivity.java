package com.chesshint.overlay;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int RC_OVERLAY = 1, RC_CAPTURE = 2, RC_NOTIF = 3;
    private TextView tvState;
    private float d;

    private int dp(float v) { return (int) (v * d + 0.5f); }

    private GradientDrawable glass(int corner, int c1, int c2, int stroke) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{c1, c2});
        g.setCornerRadius(dp(corner));
        if (stroke != 0) g.setStroke(dp(1), stroke);
        return g;
    }

    private TextView label(String t, float sp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(sp);
        v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setLineSpacing(0, 1.18f);
        return v;
    }

    private TextView button(String t, boolean primary, View.OnClickListener l) {
        TextView v = label(t, 17, 0xFFFFFFFF, true);
        v.setGravity(Gravity.CENTER);
        v.setPadding(dp(16), dp(15), dp(16), dp(15));
        v.setBackground(primary ? glass(16, 0xFF3B82F6, 0xFF1D4ED8, 0x8860A5FA) : glass(16, 0xFF1E293B, 0xFF111827, 0x663B82F6));
        v.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(12);
        v.setLayoutParams(lp);
        return v;
    }

    private LinearLayout card(String title, String body) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(14), dp(16), dp(14));
        c.setBackground(glass(18, 0xF0172036, 0xF00B1220, 0x5538BDF8));
        c.addView(label(title, 15, 0xFF7DD3FC, true));
        TextView b = label(body, 14.5f, 0xFFE2E8F0, false);
        b.setPadding(0, dp(6), 0, 0);
        c.addView(b);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(12);
        c.setLayoutParams(lp);
        return c;
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(1);   // без заголовка окна
        d = getResources().getDisplayMetrics().density;
        ScrollView sv = new ScrollView(this);
        sv.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0xFF0B1220, 0xFF111C33}));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(44), dp(20), dp(28));
        sv.addView(root);
        root.addView(label("♞  Шахматный помощник", 27, 0xFFFFFFFF, true));
        TextView sub = label("Тренажёр для партий против ботов", 15, 0xFF22D3EE, false);
        sub.setPadding(0, dp(4), 0, dp(6));
        root.addView(sub);
        root.addView(card("Как начать",
                "1. Нажмите «Запустить»: разрешите показ поверх других окон и запись экрана — в окне записи выберите «Весь экран».\n\n"
                + "2. Откройте шахматное приложение и партию против бота. Помощник сам найдёт доску и позицию — в любой момент партии.\n\n"
                + "3. Зелёная стрелка и карточка внизу показывают ход. Настройки — кнопка ⚙ на панели."));
        root.addView(card("Если что-то не так",
                "Доска не находится — ⚙ → «Калибровка»: совместите сетку с доской вручную. Фигуры определились неверно — ⚙ → «Позиция»: поправьте один раз, помощник запомнит вид фигур. "
                + "Кнопка «Скопировать отчёт» в настройках покажет, что видит приложение."));
        root.addView(card("Честная игра",
                "Всё считается на устройстве, интернет не нужен. Подсказки движка — только для тренировки против компьютера: в партиях с людьми это жульничество."));
        tvState = label("", 14, 0xFFFBBF24, false);
        tvState.setPadding(0, dp(16), 0, 0);
        root.addView(tvState);
        root.addView(button("Запустить", true, new View.OnClickListener() {
            @Override public void onClick(View v) { startFlow(); }
        }));
        root.addView(button("Остановить", false, new View.OnClickListener() {
            @Override public void onClick(View v) { stopService(new Intent(MainActivity.this, OverlayService.class)); }
        }));
        setContentView(sv);
    }

    @Override protected void onResume() {
        super.onResume();
        tvState.setText(Settings.canDrawOverlays(this) ? "Показ поверх других окон: разрешён" : "Нужно разрешение «поверх других окон»");
    }

    private void startFlow() {
        if (!Settings.canDrawOverlays(this)) {
            startActivityForResult(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())), RC_OVERLAY);
            return;
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, RC_NOTIF);
            return;
        }
        MediaProjectionManager m = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        startActivityForResult(m.createScreenCaptureIntent(), RC_CAPTURE);
    }

    @Override public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code == RC_NOTIF) startFlow();
    }

    @Override protected void onActivityResult(int code, int result, Intent data) {
        super.onActivityResult(code, result, data);
        if (code == RC_OVERLAY) {
            if (Settings.canDrawOverlays(this)) startFlow();
        } else if (code == RC_CAPTURE && result == RESULT_OK && data != null) {
            Intent i = new Intent(this, OverlayService.class);
            i.putExtra("code", result);
            i.putExtra("data", data);
            startForegroundService(i);
            moveTaskToBack(true);
        }
    }
}
